Software 2 - C195
An application for managing appointments and customers using mySQL

Written by John Costa Sr.
jcost43@wgu.edu
Submittion v2 - 02/010/2024
Built using Intellij Community Edition 2023.2.2 - JDK(Java SE 17.0.1) - JavaFX-SDK-17.0.01

Open Intellij and import the file.
After the file is imported and all files are loaded, you can start the program by opening MainApplication from the project window and run as Current File.
This will bring you to the login screen where it will accept the userName and matching password in mySQL;
This will bring you to the Directory where you can choose the main area you want to work on, Appointments, Customers, or Reports.
The Directory will also have an alert if you have an appointment within next 15 min.
Appointments will allow you to create, update, and delete appointments.
Customers will allow you to create, update, and delete customers.
Reports will allow you to see information.
There are two reports in report the first is a count of months for a selected month and count of type of a selected type
The second is appointments according to contacts.
MySQL Connector driver - mysql-connectory-java-8.0.25
