package com.example.helloworldjfxtemplate;

import java.util.Locale;
import java.util.ResourceBundle;

public class Languages {
    /*
English - Australia en en-au 3081 1252
English - Belize en en-bz 10249 2809 1252
English - Canada en en-ca 4105 1009 1252
English - Caribbean en en-cb 9225 2409 1252
English - Great Britainen en-gb 2057 809 1252
English - India en en-in 16393 4009
English - Ireland en en-ie 6153 1809 1252
English - Jamaica en en-jm 8201 2009 1252
English - New Zealanden en-nz 5129 1409 1252
English - Philippines en en-ph 13321 3409 1252
English - Southern Africa en en-za 7177 1252
English - Trinidad en en-tt 11273 1252
English - United Statesen en-us 1033 409 1252
English - Zimbabwe en 12297 3009 1252
French - Belgium fr fr-be 2060 1252
French - Cameroon fr 11276
French - Canada fr fr-ca 3084 1252
French - Congo fr 9228
French - Cote d'Ivoirefr 12300
French - France fr fr-fr 1036 1252
French - Luxembourgfr fr-lu 5132 1252
French - Mali fr 13324
French - Monaco fr 6156 1252
French - Morocco fr 14348
Locale Codes for Language
Assessment Code: QAM2
French - Senegal fr 10252
French - Switzerland fr fr-ch 4108 1252
French - West Indies fr 7180
Frisian - Netherlands 1122 462

    ResourceBundle bundle = ResourceBundle.getBundle("MessageBundle", Locale.US);

    System.out.println("Message in "+Locale.US +" = "+bundle.getString("Greetings"));
}else
    Lang_en.properties  for English

    Lang_fr.properties  for French
}*/
}