package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.customers;
import com.example.helloworldjfxtemplate.model.users;
import com.example.helloworldjfxtemplate.model.contacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.chrono.ChronoLocalDate;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 *  @author John C Costa Sr.
 */

public class AddAppointmentController implements Initializable {
    /** Appointment Field */
    public TextField appointmentIDTF;
    /** Title Field */
    public TextField titleTF;
    /** Description Field */
    public TextField descriptionTF;
    /** Location Field */
    public TextField locationTF;
    /** Type Field */
    public TextField typeTF;

    /** Contact ComboBox */
    public ComboBox contactBox;
    /** Customer ComboBox */
    public ComboBox customerIDBox;
    /** User ComboBox */
    public ComboBox userIDBox;
    /** StartTime ComboBox */
    public ComboBox startTimeBox;
    /** EndTime ComboBox */
    public ComboBox endTimeBox;

    /** Save Button */
    public Button save;
    /** Cancel Button */
    public Button cancel;
    /** StartDate DatePicker */
    public DatePicker startDatePick;
    /** EndDate DatePicker */
    public DatePicker endDatePick;

    /** Add Appointment Label */
    public Label addAppt;
    /** Appointment ID Label */
    public Label appointmentID;
    /** Title Label */
    public Label title;
    /** Description Label */
    public Label description;
    /** Location Label */
    public Label location;
    /** Contact Label */
    public Label contact;
    /** Type Label */
    public Label type;
    /** Start Time Label */
    public Label startTime;
    /** End Time Label */
    public Label endTime;
    /** Customer ID Label */
    public Label customerID;
    /** User ID Label */
    public Label userID;
    /** Start Date Label */
    public Label startDate;
    /** End Date Label */
    public Label endDate;

    /** Save - OnAction */
    public void onClickSaveAddAppointment(ActionEvent actionEvent) throws IOException, SQLException {

        try {
            String titleField = titleTF.getText();
            if (titleTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Title and all other fields");
                return;
            }
            String descriptionField = descriptionTF.getText();
            if (descriptionTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Description and all other fields");
                return;
            }
            String locationField = locationTF.getText();
            if (locationTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Location and all other fields");
                return;
            }
            String typeField = typeTF.getText();
            if (typeTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Type and all other fields");
                return;
            }
            if(contactBox.getValue() == null){
                MainApplication.confirmPopUp("Input Error", "No contact selected, please select a contact");
                return;
            }
            if (!(startDatePick.getValue().equals(endDatePick.getValue()))){
                MainApplication.confirmPopUp("Input Error", "Appointment start and end are on separate days, must be the same day.");
                return;
            }
            if (startTimeBox.getValue().equals(endTimeBox.getValue())){
                MainApplication.confirmPopUp("Input Error", "Appointment start and end time are set to the same time.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(6, 0)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(6, 15)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(6, 30)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(6, 45)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(7, 0)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(7, 15)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(7, 30)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (startTimeBox.getValue().equals(
                    (LocalTime.of(7, 45)))){
                MainApplication.confirmPopUp("Input Error", "Appointment start time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(22, 00)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(22, 15)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(22, 30)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(22, 45)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(23, 00)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(23, 15)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(23, 30)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            if (endTimeBox.getValue().equals(
                    (LocalTime.of(23, 45)))){
                MainApplication.confirmPopUp("Input Error", "Appointment end time not within business hours.");
                return;
            }
            LocalTime sStartTime = LocalTime.parse(startTimeBox.getValue().toString());
            LocalTime sEndTime = LocalTime.parse(endTimeBox.getValue().toString());
            if (sStartTime.isAfter(sEndTime)){
                MainApplication.confirmPopUp("Input Error", "Appointment start time is after the requested end time.");
                return;
            }
            if(customerIDBox.getValue() == null){
                MainApplication.confirmPopUp("Input Error", "No Customer ID selected, please select a Customer ID");
                return;
            }
            if(userIDBox.getValue() == null){
                MainApplication.confirmPopUp("Input Error", "No User ID selected, please select a User ID");
                return;
            }

            int contactField =  Integer.parseInt(String.valueOf(contactBox.getValue()));
            Timestamp startDateTime = Timestamp.valueOf(LocalDateTime.of(startDatePick.getValue(), (LocalTime) startTimeBox.getValue()));
            Timestamp endDateTime = Timestamp.valueOf(LocalDateTime.of(endDatePick.getValue(), (LocalTime) endTimeBox.getValue()));
            int customerIDField = Integer.parseInt(String.valueOf(customerIDBox.getValue()));
            int userIDField = Integer.parseInt(String.valueOf(userIDBox.getValue()));
//            System.out.println(contactField);
//            System.out.println(startDateTime);
//            System.out.println(endDateTime);
//            System.out.println(customerIDField);
//            System.out.println(userIDField);

            try {
                String sql = "SElECT * FROM appointments";
                PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                int customerId = 0;
                LocalDateTime customerStartTime;
                LocalDateTime customerEndTime;
                while (rs.next()) {
                    customerId = rs.getInt("Customer_ID");
                    customerStartTime = rs.getTimestamp("Start").toLocalDateTime();
                    customerEndTime = rs.getTimestamp("End").toLocalDateTime();
                    if(customerIDBox.getValue().equals(customerId)){
                        if(startDatePick.getValue().toString().substring(0,10).equals(customerStartTime.toString().substring(0,10))) {
                            if (((LocalTime) startTimeBox.getValue()).isAfter(LocalTime.from(customerStartTime)) && ((LocalTime) startTimeBox.getValue()).isBefore(LocalTime.from(customerEndTime))) {
                                MainApplication.confirmPopUp("Input Error", "Conflicting appointment dates, times");
                                return;
                            } else if (((LocalTime) endTimeBox.getValue()).isAfter(LocalTime.from(customerStartTime)) && ((LocalTime) endTimeBox.getValue()).isBefore(LocalTime.from(customerEndTime))) {
                                MainApplication.confirmPopUp("Input Error", "Conflicting appointment dates, times");
                                return;
                            }
                        }
                    }
                }
            } catch (Exception e) {
            //blank
        }
            LocalDateTime createDate = LocalDateTime.now();
            String createdBy = "script";
            LocalDateTime lastUpdate = LocalDateTime.now();
            String lastUpdatedBy = "script";
            System.out.println(contactBox.getValue());

                    JDBC.makeConnection();    int rowsAffected = QueryManager.insertAppointment(0, titleField, descriptionField, locationField, typeField, startDateTime, endDateTime, createDate, createdBy, lastUpdate, lastUpdatedBy, customerIDField, userIDField, (Integer) contactBox.getValue());

            if (rowsAffected > 0) {
                    System.out.println("Selected Add Successful!");
                } else {
                    System.out.println("Selected Add Failure!");
                }

            }catch(Exception e){
                MainApplication.confirmPopUp("Input Error", "Check fields for correct input entry");
                return;
            }
            Stage stage = (Stage) save.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("appointments.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("");
            stage.setScene(scene);

    }
    /** Cancel - OnAction */
    public void onClickCancelAddAppointment(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) cancel.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("appointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        /** Populate Contacts ComboBox */
        try {
            String sql = "SElECT * FROM contacts";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int contactIDTxt = 0;
            while (rs.next()) {
                contactIDTxt = rs.getInt("Contact_ID");
                contactBox.getItems().addAll(contactIDTxt);
            }
        }catch (Exception e){
            //blank
        }

        /** Populate Customer ComboBox */
        try {
            String sql = "SElECT * FROM customers";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int customerIDtxt = 0;
            while (rs.next()) {
                customerIDtxt = rs.getInt("Customer_ID");
                customerIDBox.getItems().addAll(customerIDtxt);
            }
        }catch (Exception e){
            //blank}
        }

        /** Populate Users ComboBox */
        try {
            String sql = "SElECT * FROM users";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int userIDtxt = 0;
            while (rs.next()) {
                userIDtxt = rs.getInt("User_ID");
                userIDBox.getItems().addAll(userIDtxt);
            }
        }catch (Exception e){
            //blank}
        }

        /** Populate Time ComboBox */
        LocalTime start = LocalTime.of(6, 0);
        LocalTime end = LocalTime.of(23, 0);
        while (start.isBefore(end.plusSeconds(1))) {
            startTimeBox.getItems().add(start);
            start = start.plusMinutes(15);
            startTimeBox.getSelectionModel().select(LocalTime.of(8, 0));
            endTimeBox.getItems().add(start);
            endTimeBox.getSelectionModel().select(LocalTime.of(10, 0));
        }

        System.out.println("Add Appointment Controller Initialized!");
    }
}
