package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.controller.LoginController;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.stream.Stream;

import static java.util.Locale.filter;
import static javafx.scene.input.KeyCode.T;

/**
 * @author John C Costa Sr.
 */

public class AddCustomerController implements Initializable {
    /** Customer ID Field */
    public TextField customerIDTF;
    /** Customer First Name Field */
    public TextField customerFirstNameTF;
    /** Customer Last Name Field */
    public TextField customerLastNameTF;
    /** Address Field */
    public TextField addressTF;
    /** Postal Code Field */
    public TextField postalCodeTF;
    /** Phone Number Field */
    public TextField phoneNumberTF;
    /** Save Button */
    public Button save;
    /** Cancel Button */
    public Button cancel;
    /** Add Customer Label */
    public Label addCustomer;
    /** Customer ID Label */
    public Label customerID;
    /** Customer First Name Label */
    public Label customerFirstName;
    /** Customer Last Name Label */
    public Label customerLastName;
    /** Address Label */
    public Label address;
    /** State or Provence Label */
    public Label stateProvence;
    /** Country Label */
    public Label country;
    /** Postal Code */
    public Label postalCode;
    /** Phone Number Label */
    public Label phoneNumber;
    /** Country ComboBox */
    public ComboBox countryBox;
    /** State or Provence ComboBox */
    public ComboBox stateProvenceBox;

    /** Variables */
    public int divisionID = 0;



    /** Save - OnAction */
    public void onClickSaveAddCustomer(ActionEvent actionEvent) throws IOException, SQLException {

        String customerNameField = customerFirstNameTF.getText() + " " + customerLastNameTF.getText();
        if (customerFirstNameTF.getText().isEmpty()){
            MainApplication.confirmPopUp("Input Error", "No information added to the Customer First Name field");
            return;
        }
        if (customerLastNameTF.getText().isEmpty()){
            MainApplication.confirmPopUp("Input Error", "No information added to the Customer Last Name field");
            return;
        }
        if (addressTF.getText().isEmpty()){
            MainApplication.confirmPopUp("Input Error", "No information added to the Address field");
            return;
        }
        if (phoneNumberTF.getText().isEmpty()) {
            MainApplication.confirmPopUp("Input Error", "No information added to the Phone Number field");
            return;
        }
        if(countryBox.getItems().isEmpty()){
            MainApplication.confirmPopUp("Input Error", "No Country selected, please Select a Country.");
            return;
        }
        if(stateProvenceBox.getItems().isEmpty()){
            MainApplication.confirmPopUp("Input Error", "No State or Provence was selected, please select a State or Provence. (A country must also be provided for this listing)");
            return;
        }
        if(stateProvenceBox.getValue().equals("Alabama")){
            divisionID = 1;
        }
        else if(stateProvenceBox.getValue().equals("Arizona")){
            divisionID = 2;
        }
        else if(stateProvenceBox.getValue().equals("Arkansas")){
            divisionID = 3;
        }
        else if(stateProvenceBox.getValue().equals("California")){
            divisionID = 4;
        }
        else if(stateProvenceBox.getValue().equals("Colorado")){
            divisionID = 5;
        }
        else if(stateProvenceBox.getValue().equals("Connecticut")){
            divisionID = 6;
        }
        else if(stateProvenceBox.getValue().equals("Delaware")){
            divisionID = 7;
        }
        else if(stateProvenceBox.getValue().equals("District of Columbia")){
            divisionID = 8;
        }
        else if(stateProvenceBox.getValue().equals("Florida")){
            divisionID = 9;
        }
        else if(stateProvenceBox.getValue().equals("Georgia")){
            divisionID = 10;
        }
        else if(stateProvenceBox.getValue().equals("Idaho")){
            divisionID = 11;
        }
        else if(stateProvenceBox.getValue().equals("Illinois")){
            divisionID = 12;
        }
        else if(stateProvenceBox.getValue().equals("Indiana")){
            divisionID = 13;
        }
        else if(stateProvenceBox.getValue().equals("Iowa")){
            divisionID = 14;
        }
        else if(stateProvenceBox.getValue().equals("Kansas")){
            divisionID = 15;
        }
        else if(stateProvenceBox.getValue().equals("Kentucky")){
            divisionID = 16;
        }
        else if(stateProvenceBox.getValue().equals("Louisiana")){
            divisionID = 17;
        }
        else if(stateProvenceBox.getValue().equals("Maine")){
            divisionID = 18;
        }
        else if(stateProvenceBox.getValue().equals("Maryland")){
            divisionID = 19;
        }
        else if(stateProvenceBox.getValue().equals("Massachusetts")){
            divisionID = 20;
        }
        else if(stateProvenceBox.getValue().equals("Michigan")){
            divisionID = 21;
        }
        else if(stateProvenceBox.getValue().equals("Minnesota")){
            divisionID = 22;
        }
        else if(stateProvenceBox.getValue().equals("Mississippi")){
            divisionID = 23;
        }
        else if(stateProvenceBox.getValue().equals("Missouri")){
            divisionID = 24;
        }
        else if(stateProvenceBox.getValue().equals("Montana")){
            divisionID = 25;
        }
        else if(stateProvenceBox.getValue().equals("Nebraska")){
            divisionID = 26;
        }
        else if(stateProvenceBox.getValue().equals("Nevada")){
            divisionID = 27;
        }
        else if(stateProvenceBox.getValue().equals("New Hampshire")){
            divisionID = 28;
        }
        else if(stateProvenceBox.getValue().equals("New Jersey")){
            divisionID = 29;
        }
        else if(stateProvenceBox.getValue().equals("New Mexico")){
            divisionID = 30;
        }
        else if(stateProvenceBox.getValue().equals("New York")){
            divisionID = 31;
        }
        else if(stateProvenceBox.getValue().equals("North Carolina")){
            divisionID = 32;
        }
        else if(stateProvenceBox.getValue().equals("North Dakota")){
            divisionID = 33;
        }
        else if(stateProvenceBox.getValue().equals("Ohio")){
            divisionID = 34;
        }
        else if(stateProvenceBox.getValue().equals("Oklahoma")){
            divisionID = 35;
        }
        else if(stateProvenceBox.getValue().equals("Oregon")){
            divisionID = 36;
        }
        else if(stateProvenceBox.getValue().equals("Pennsylvania")){
            divisionID = 37;
        }
        else if(stateProvenceBox.getValue().equals("Rhode Island")) {
            divisionID = 38;
        }
        else if(stateProvenceBox.getValue().equals("South Carolina")){
            divisionID = 39;
        }
        else if(stateProvenceBox.getValue().equals("South Dakota")){
            divisionID = 40;
        }
        else if(stateProvenceBox.getValue().equals("Tennessee")){
            divisionID = 41;
        }
        else if(stateProvenceBox.getValue().equals("Texas")){
            divisionID = 42;
        }
        else if(stateProvenceBox.getValue().equals("Utah")){
            divisionID = 43;
        }
        else if(stateProvenceBox.getValue().equals("Vermont")){
            divisionID = 44;
        }
        else if(stateProvenceBox.getValue().equals("Virginia")){
            divisionID = 45;
        }
        else if(stateProvenceBox.getValue().equals("Washington")){
            divisionID = 46;
        }
        else if(stateProvenceBox.getValue().equals("West Virginia")){
            divisionID = 47;
        }
        else if(stateProvenceBox.getValue().equals("Wisconsin")){
            divisionID = 48;
        }
        else if(stateProvenceBox.getValue().equals("Wyoming")){
            divisionID = 49;
        }
        else if(stateProvenceBox.getValue().equals("Hawaii")){
            divisionID = 52;
        }
        else if(stateProvenceBox.getValue().equals("Alaska")){
            divisionID = 54;
        }
        else if(stateProvenceBox.getValue().equals("Northwest Territories")){
            divisionID = 60;
        }
        else if(stateProvenceBox.getValue().equals("Alberta")){
            divisionID = 61;
        }
        else if(stateProvenceBox.getValue().equals("British Columbia")){
            divisionID = 62;
        }
        else if(stateProvenceBox.getValue().equals("Manitoba")){
            divisionID = 63;
        }
        else if(stateProvenceBox.getValue().equals("New Brunswick")){
            divisionID = 64;
        }
        else if(stateProvenceBox.getValue().equals("Nova Scotia")){
            divisionID = 65;
        }
        else if(stateProvenceBox.getValue().equals("Prince Edward Island")){
            divisionID = 66;
        }
        else if(stateProvenceBox.getValue().equals("Ontario")){
            divisionID = 67;
        }
        else if(stateProvenceBox.getValue().equals("Québec")){
            divisionID = 68;
        }
        else if(stateProvenceBox.getValue().equals("Saskatchewan")){
            divisionID = 69;
        }
        else if(stateProvenceBox.getValue().equals("Nunavut")){
            divisionID = 70;
        }
        else if(stateProvenceBox.getValue().equals("Yukon")){
            divisionID = 71;
        }
        else if(stateProvenceBox.getValue().equals("Newfoundland and Labrador")) {
            divisionID = 72;
        }
        else if(stateProvenceBox.getValue().equals("England")){
            divisionID = 101;
        }
        else if(stateProvenceBox.getValue().equals("Wales")){
            divisionID = 102;
        }
        else if(stateProvenceBox.getValue().equals("Scotland")){
            divisionID = 103;
        }
        else if(stateProvenceBox.getValue().equals("Northern Ireland")){
            divisionID = 104;
        }
        System.out.println(divisionID);
        LocalDateTime createDate = LocalDateTime.now();
        String createdBy = "script";
        LocalDateTime lastUpdate = LocalDateTime.now();
        String lastUpdatedBy = "script";

        int rowsAffected = QueryManager.insertCustomer(customerNameField, addressTF.getText(), postalCodeTF.getText(), phoneNumberTF.getText(), createDate, createdBy, lastUpdate, lastUpdatedBy, divisionID);
        if (rowsAffected > 0) {
            System.out.println("Selected Add Customer Successful!");
        } else {
            System.out.println("Selected Add Customer Failure!");
        }

        Stage stage = (Stage) save.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }
    /** Cancel - OnAction */
    public void onClickCancelAddCustomer(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) cancel.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        /** Populate Country Box */
        try {
            String sql = "SElECT * FROM countries";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            String countrytxt = null;
            while (rs.next()) {
                countrytxt = rs.getString("Country");
                countryBox.getItems().add(countrytxt);
            }
        }catch (Exception e){
            //blank
        }
        /** Country ComboBox Listener */
        countryBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            int divisionId = 0;
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {

               if (countryBox.getValue().toString().equals("U.S")) { // division ID 1 - 72, country ID 1
                   try {
                       String sql = "SElECT * FROM first_level_divisions";
                       PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                       ResultSet rs = ps.executeQuery();

                       String divisontxt = null;
                       int countryIDtxt = 0;
                       while (rs.next()) {
                           divisionId = rs.getInt("Division_ID");
                           divisontxt = rs.getString("Division");
                           countryIDtxt = rs.getInt("Country_ID");
                            if(countryIDtxt == 1) {
                                stateProvenceBox.getItems().addAll(divisontxt);
                            }
                            else if (countryIDtxt != 1) {

                               stateProvenceBox.getItems().remove(divisontxt);
                            }
                       }

                   } catch (Exception e) {
                       //blank
                   }
                   System.out.println(stateProvenceBox.getValue());


                    System.out.println("U.S");
                }else if (countryBox.getValue().toString().equals("UK")) { // division ID 1 - 72, country ID 1
                    //Stream<T> filter(Predicate<? super T> predicate)
                    try {
                        String sql = "SElECT * FROM first_level_divisions";
                        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        String divisontxt = null;
                        int countryIDtxt = 0;
                        while (rs.next()) {
                            divisionId = rs.getInt("Division_ID");
                            divisontxt = rs.getString("Division");
                            countryIDtxt = rs.getInt("Country_ID");
                            if (countryIDtxt == 2) {
                                stateProvenceBox.getItems().add(divisontxt);
                            }
                            if (countryIDtxt != 2) {

                                stateProvenceBox.getItems().remove(divisontxt);
                            }
                        }
                    } catch (Exception e) {
                        //blank
                    }
                   System.out.println(divisionId);

                    System.out.println("U.K");
                }else if (countryBox.getValue().equals("Canada")) { // division ID 1 - 72, country ID 1
                    try {
                        String sql = "SElECT * FROM first_level_divisions";
                        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        String divisontxt = null;
                        int countryIDtxt = 0;
                        while (rs.next()) {
                            divisionId = rs.getInt("Division_ID");
                            divisontxt = rs.getString("Division");
                            countryIDtxt = rs.getInt("Country_ID");
                            if(countryIDtxt == 3) {
                                stateProvenceBox.getItems().add(divisontxt);
                            }
                            if (countryIDtxt != 3) {

                                stateProvenceBox.getItems().remove(divisontxt);
                            }
                        }
                        divisionID = stateProvenceBox.getValue().toString().indexOf(" ",0);
                        System.out.println(divisionID);
                    } catch (Exception e) {
                        //blank
                    }

                    //System.out.println("Canada");
                }
                divisionID = divisionId;
            }
        });



        System.out.println("Add Customer Controller Initialized!");
    }
}