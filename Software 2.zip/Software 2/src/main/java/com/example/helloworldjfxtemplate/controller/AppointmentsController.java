package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.*;
import java.time.chrono.ChronoLocalDateTime;
import java.time.temporal.WeekFields;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * @author John C Costa SR.
 */

public class AppointmentsController implements Initializable {
    /** Appointment Table */
    public TableView<appointments> appointmentsTable;
    /** Appointment ID Column */
    public TableColumn <appointments, Integer>  appointmentID;
    /** Title Column */
    public TableColumn <appointments, String> title;
    /** Description Column */
    public TableColumn <appointments, String> description;
    /** Locaiton Column */
    public TableColumn <appointments, String> location;
    /** Contact Column */
    public TableColumn <appointments, Integer> contact;
    /** Type Column */
    public TableColumn <appointments, String> type;
    /** StartDateTime Column */
    public TableColumn <appointments, ZonedDateTime> startDateTime;
    /** EndDateTime Column */
    public TableColumn <appointments, ZonedDateTime> endDateTime;
    /** Customer ID Column */
    public TableColumn <appointments, Integer> customerID;
    /** User ID Column */
    public TableColumn <appointments, Integer> userID;
    /** Appointments ToggleGroup */
    public ToggleGroup Appointments;
    /** Return to Directory Button */
    public Button returnGUI;
    /** Add Button */
    public Button add;
    /** Update Button */
    public Button update;
    /** Delete Button */
    public Button delete;
    /** Appointment Schedule Label */
    public Label apptSchedule;
    /** Month RadioButton */
    public RadioButton apptMonth;
    /** Week RadioButton */
    public RadioButton apptWeek;
    /** All Appointment RadioButton */
    public RadioButton allAppt;

    /** Delete - OnAction */
    public void onClickDeleteAppointmentSchedule(ActionEvent actionEvent) throws SQLException, IOException {

        if(appointmentsTable.getSelectionModel().isEmpty()){
            MainApplication.popUp("Error", "No items were selected","Please select an item if within the Table");
        } else {
            MainApplication.confirmPopUp("Delete from Table", "Would you like to remove this item?");
            int rowsAffected = QueryManager.deleteAppointment(appointmentsTable.getSelectionModel().getSelectedItem().getAppointmentID());
            if (rowsAffected > 0) {
                appointmentsTable.setItems(QueryManager.selectAppointment());
                System.out.println("Selected Delete Successful!");
            } else {
                System.out.println("Selected Delete Failure!");
            }
        }

    }

    /** Update - OnAction */
    public void onClickUpdateAppointmentSchedule(ActionEvent actionEvent) throws IOException {
        if (appointmentsTable.getSelectionModel().isEmpty()){
            MainApplication.popUp("Error", "No items were selected","Please select an item if within the Table");
        }else {

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/com/example/helloworldjfxtemplate/updateAppointment.fxml"));
            Parent parentIn = loader.load();
            int index = appointmentsTable.getSelectionModel().getSelectedIndex();
            UpdateAppointmentController updateAppointmentController = loader.getController();
            updateAppointmentController.sendData(index, appointmentsTable.getSelectionModel().getSelectedItem());
            Scene scene = new Scene(parentIn);
            Stage stage = (Stage) (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /** Add - OnActin */
    public void onClickAddAppointmentSchedule(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) add.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("addAppointment.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Return to Directory - OnAction */
    public void onClickReturn(ActionEvent actionEvent) throws IOException {

        Stage stage = (Stage) returnGUI.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("directoryGUI.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Appointments Observable List */
    ObservableList<appointments> appointmentsObservableList = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        if(apptMonth.isSelected()){

            ObservableList<appointments> monthFilter = FXCollections.observableArrayList();

            appointmentsObservableList.forEach(a->{

                Month currentMonth = LocalDateTime.now().getMonth();
                a.getStartDateTime().getMonth();

                if (currentMonth == a.getStartDateTime().getMonth()){
                    monthFilter.add(a);
                }
            });
            appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
            title.setCellValueFactory(new PropertyValueFactory<>("title"));
            description.setCellValueFactory(new PropertyValueFactory<>("description"));
            location.setCellValueFactory(new PropertyValueFactory<>("location"));
            contact.setCellValueFactory(new PropertyValueFactory<>("contactID"));
            type.setCellValueFactory(new PropertyValueFactory<>("type"));
            startDateTime.setCellValueFactory((new PropertyValueFactory<>("startDateTime")));
            endDateTime.setCellValueFactory(new PropertyValueFactory<>("endDateTime"));
            customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
            userID.setCellValueFactory(new PropertyValueFactory<>("userID"));
            appointmentsTable.setItems(monthFilter);

            System.out.println("Filtered By Month");
        }


        if (apptWeek.isSelected()){

                ObservableList<appointments> weekFilter = FXCollections.observableArrayList();

                appointmentsObservableList.forEach(a->{

                    DayOfWeek currentWeek = LocalDateTime.now().getDayOfWeek();
                    a.getStartDateTime().getDayOfWeek();

                    if (currentWeek == a.getStartDateTime().getDayOfWeek()){
                        weekFilter.add(a);
                    }

                });

                        appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
                        title.setCellValueFactory(new PropertyValueFactory<>("title"));
                        description.setCellValueFactory(new PropertyValueFactory<>("description"));
                        location.setCellValueFactory(new PropertyValueFactory<>("location"));
                        contact.setCellValueFactory(new PropertyValueFactory<>("contactID"));
                        type.setCellValueFactory(new PropertyValueFactory<>("type"));
                        startDateTime.setCellValueFactory((new PropertyValueFactory<>("startDateTime")));
                        endDateTime.setCellValueFactory(new PropertyValueFactory<>("endDateTime"));
                        customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
                        userID.setCellValueFactory(new PropertyValueFactory<>("userID"));
                        appointmentsTable.setItems(weekFilter);


                System.out.println("Filtered By Week");

        }
        else {

                String sql = "SELECT Appointment_ID, Title, Description, Location, Contact_ID, Type, Start, End, Customer_ID, User_ID FROM appointments";
                try {
                    PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        Integer appointmentIDField = rs.getInt("Appointment_ID");
                        String titleField = rs.getString("Title");
                        String descriptionField = rs.getString("Description");
                        String locationField = rs.getString("Location");
                        int contactField = rs.getInt("Contact_ID");
                        String typeField = rs.getString("Type");
                        LocalDateTime startDateTimeField = rs.getTimestamp("Start").toLocalDateTime();
                        LocalDateTime endDateTimeField = rs.getTimestamp("End").toLocalDateTime();
                        int customerIDField = rs.getInt("Customer_ID");
                        String userIDField = rs.getString("User_ID");

                        appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
                        title.setCellValueFactory(new PropertyValueFactory<>("title"));
                        description.setCellValueFactory(new PropertyValueFactory<>("description"));
                        location.setCellValueFactory(new PropertyValueFactory<>("location"));
                        contact.setCellValueFactory(new PropertyValueFactory<>("contactID"));
                        type.setCellValueFactory(new PropertyValueFactory<>("type"));
                        startDateTime.setCellValueFactory((new PropertyValueFactory<>("startDateTime")));
                        endDateTime.setCellValueFactory(new PropertyValueFactory<>("endDateTime"));
                        customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
                        userID.setCellValueFactory(new PropertyValueFactory<>("userID"));

                        appointmentsObservableList.add(new appointments(appointmentIDField, titleField, descriptionField, locationField, contactField, typeField,
                                startDateTimeField, endDateTimeField, customerIDField, userIDField));
                    }
                } catch (SQLException e) {
                    System.out.println("Error: " + e.getMessage());
                }
                appointmentsTable.setItems(appointmentsObservableList);
            }

        System.out.println("Appointments Controller Initialized!");
    }

    /** Lambda - Month Filter RadioButton */
    public void apptMonthR(ActionEvent actionEvent) {

        ObservableList<appointments> monthFilter = FXCollections.observableArrayList();

        appointmentsObservableList.forEach(a -> {

            Month currentMonth = LocalDateTime.now().getMonth();

            a.getStartDateTime().getMonth();

            if (currentMonth == a.getStartDateTime().getMonth()) {
                monthFilter.add(a);
            }

        });
        appointmentsTable.setItems(monthFilter);

        System.out.println("Filtered By Month");
    }
    /** Lambda - Week Filter RadioButton */
    public void apptWeekR(ActionEvent actionEvent) {
        ObservableList<appointments> weekFilter = FXCollections.observableArrayList();

        appointmentsObservableList.forEach(a->{

            DayOfWeek currentWeek = LocalDateTime.now().getDayOfWeek();

            a.getStartDateTime().getDayOfWeek();

            if (currentWeek == a.getStartDateTime().getDayOfWeek()) {
                weekFilter.add(a);
            }

        });
                appointmentsTable.setItems(weekFilter);

        System.out.println("Filtered By Week");
    }
    /** All Appointments RadioButton */
    public void allApptR(ActionEvent actionEvent) {
        appointmentsTable.setItems(appointmentsObservableList);

        System.out.println("No filter applied");
    }

}

