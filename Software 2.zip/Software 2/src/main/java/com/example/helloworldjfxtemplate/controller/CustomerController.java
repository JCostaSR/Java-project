package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.appointments;
import com.example.helloworldjfxtemplate.model.customers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * @author John C Costa Sr.
 */

public class CustomerController implements Initializable {
    /** Customer Table */
    public TableView<customers> customersTableView;
    /** Customer ID Column */
    public TableColumn<customers, Integer> customerID;
    /** Customer Name Column */
    public TableColumn <customers, String> customerName;
    /** Address Column */
    public TableColumn <customers, String> address;
    /** Postal Code Column */
    public TableColumn <customers, String> postalCode;
    /** Phone Number Column */
    public TableColumn <customers, String> phoneNumber;
    /** Add Button */
    public Button add;
    /** Update Button */
    public Button update;
    /** Delete Button */
    public Button delete;
    /** Return to Directory Button */
    public Button returnGUI;
    /** Customer Information Label */
    public Label customerInfo;

    /** Delete - OnAction */
    public void onClickDeleteCustomerInformation(ActionEvent actionEvent) throws SQLException {
        if(customersTableView.getSelectionModel().isEmpty()){

            MainApplication.popUp("Error", "No items were selected","Please select an item if within the Table");
        } else {
            MainApplication.confirmPopUp("Delete from Table", "Would you like to remove this item?");

            String sql = "SELECT Customer_ID FROM appointments";
            int customerId = 0;
            try {
                PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while(rs.next()) {
                    customerId = rs.getInt(1);
                    if (customersTableView.getSelectionModel().getSelectedItem().getCustomerID() == customerId){
                        MainApplication.confirmPopUp("Unable to Remove", "Customer has a pending appointment!");
                        return;
                    }
                }

            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }

            int rowsAffected = QueryManager.deleteCustomer(customersTableView.getSelectionModel().getSelectedItem().getCustomerID());
            if (rowsAffected > 0) {
                customersTableView.setItems(QueryManager.selectCustomer());
                System.out.println("Selected Delete Successful!");
            } else {
                System.out.println("Selected Delete Failure!");
            }

        }
        customersTableView.setItems(customersObservableList);
    }

    /** Update - OnAction */
    public void onClickUpdateCustomerInformation(ActionEvent actionEvent) throws IOException {
        if (customersTableView.getSelectionModel().isEmpty()){
            MainApplication.popUp("Error", "No items were selected","Please select an item if within the Table");
        }else {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/com/example/helloworldjfxtemplate/updateCustomer.fxml"));
            Parent parentIn = loader.load();
            int index = customersTableView.getSelectionModel().getSelectedIndex();
            UpdateCustomerController updateCustomerController = loader.getController();
            updateCustomerController.sendCustomerData(index, customersTableView.getSelectionModel().getSelectedItem());
            Scene scene = new Scene(parentIn);
            Stage stage = (Stage) (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /** Add - OnAction */
    public void onClickAddCustomerInformation(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) add.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("addCustomer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Return to Directory - OnAction */
    public void onClickReturn(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) returnGUI.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("directoryGUI.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Customer ObservableList */
    ObservableList<customers> customersObservableList = FXCollections.observableArrayList();
    /** Customer CheckList Observable List */
    ObservableList<appointments> customersCheckList = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        /** Populate Customer Table */
        String sql = "SELECT Customer_ID, Customer_Name, Address, Postal_Code, Phone FROM customers";
        try {
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int customerIDField = rs.getInt(1);
                String customerNameField = rs.getString(2);
                String addressField = rs.getString(3);
                String postalCodeField = rs.getString(4);
                String phoneNumberField = rs.getString(5);

                customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
                customerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
                address.setCellValueFactory(new PropertyValueFactory<>("address"));
                postalCode.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
                phoneNumber.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
                //System.out.println(customerIDField + " " + customerNameField + " " + addressField + " " + phoneNumberField + " " + phoneNumberField);
                customersObservableList.add(new customers(customerIDField, customerNameField, addressField, postalCodeField, phoneNumberField));
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        customersTableView.setItems(customersObservableList);

    System.out.println("Customer Controller Initialized!");
    }

    public void setText(String customerName) {
    }
}