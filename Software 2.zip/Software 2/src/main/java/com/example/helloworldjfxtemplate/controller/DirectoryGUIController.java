package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.appointments;
import com.example.helloworldjfxtemplate.model.customers;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.chrono.ChronoLocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.Predicate;

/**
 * @author John C Costa SR.
 */

public class DirectoryGUIController implements Initializable {

    /** Appointment Table */
    public TableView <appointments> appointmentTable;
    /** Appointment ID Column */
    public TableColumn<appointments, Integer> appointmentID;
    /** Title Column */
    public TableColumn <appointments, String> title;
    /** Type Column */
    public TableColumn <appointments, String> type;
    /** Start Date Time Column */
    public TableColumn <appointments, LocalDateTime> startDateTime;
    /** End Date Time Column */
    public TableColumn <appointments, LocalDateTime> endDateTime;
    /** Customer ID Column */
    public TableColumn <appointments, String> customerID;
    /** Appointments Directory Button */
    public Button appointmentsGUIBtn;
    /** Customer Directory Button */
    public Button customersGUIBtn;
    /** Reports Directory Button */
    public Button reportsGUIBtn;
    /** Directory Label */
    public Label directory;
    /** Alert Label */
    public Label AlertLbl;

    /** Sign out Button */
    public Button signOut;

    Connection connection;

    /** Go to Appointments - OnAction */
    public void onClickNavAppointments(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) appointmentsGUIBtn.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("appointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Go to Customer - OnAction */
    public void onClickNavCustomers(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) customersGUIBtn.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Go to Reports - OnAction */
    public void onClickNavReports(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) reportsGUIBtn.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("reports.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Sign Out - OnAction */
    public void onClickSignOut(ActionEvent actionEvent) { System.exit(0);  }

    /** Appointments ObservableList */
    ObservableList<appointments> appointmentsObservableList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        /** Keys for language settings */
        //Locale.setDefault(new Locale("fr"));
        ResourceBundle lang = ResourceBundle.getBundle("Lang", Locale.getDefault());
        AlertLbl.setText(lang.getString("AlertLbl"));


        LocalDateTime startDT = LocalDateTime.now();
        LocalDateTime endDT = LocalDateTime.now().withMinute(15);
        LocalDateTime myDT = LocalDateTime.now().withMinute(10);

        /** Populate Appointment Table */
        String sql = "SELECT Appointment_ID, Title, Type, Start, End, Customer_ID FROM appointments";
        try {
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                Integer appointmentIDField = rs.getInt("Appointment_ID");
                String titleField = rs.getString("Title");
                String typeField = rs.getString("Type");
                LocalDateTime startDateTimeField = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime endDateTimeField = rs.getTimestamp("End").toLocalDateTime();
                int customerIDField = rs.getInt("Customer_ID");

                appointmentsObservableList.add(new appointments(appointmentIDField, titleField, typeField, startDateTimeField, endDateTimeField, customerIDField));


            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        appointmentTable.setItems(appointmentsObservableList);

        appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        title.setCellValueFactory(new PropertyValueFactory<>("title"));
        type.setCellValueFactory(new PropertyValueFactory<>("type"));
        startDateTime.setCellValueFactory(new PropertyValueFactory<>("startDateTime"));
        endDateTime.setCellValueFactory(new PropertyValueFactory<>("endDateTime"));
        customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));

        /** Alert for upcoming appointments */
        for(appointments appt : appointmentsObservableList) {
            LocalTime startTime = LocalTime.from(appt.getStartDateTime());
            LocalTime currentTime = LocalTime.now();
            long timeDifference = ChronoUnit.MINUTES.between(currentTime, startTime);

            long interval = timeDifference;
            System.out.println("Current Time" + currentTime);
            System.out.println("Start Time " + startTime);
            System.out.println(interval);
            if (Locale.getDefault().equals(Locale.forLanguageTag("fr"))) {
                if (interval > 0 && interval <= 15) {
                MainApplication.confirmPopUp("Rendez-vous à venir", "Vous avez un rendez-vous à venir à environ " + startTime + "!");
                System.out.println("Vous avez un rendez-vous à venir à " + startTime + "!");
                AlertLbl.setText(" ");
            } else if (interval <= 0) {
                System.out.println("Vous n'avez pas de rendez-vous à venir");

            }
            }
            if (Locale.getDefault().equals(Locale.forLanguageTag("en-US"))) {
                if (interval > 0 && interval <= 15) {
                MainApplication.confirmPopUp("Upcoming Appointment", "You have an upcoming appointment at approximately " + startTime + "!");
                System.out.println("You have an appointment coming up at " + startTime + "!");
                AlertLbl.setText(" ");
            } else if (interval <= 0) {
                System.out.println("You have no upcoming appointments");
                }
            }
                System.out.println(Locale.getDefault());

        }
        System.out.println("Directory GUI Controller Initialized!");

    }
}