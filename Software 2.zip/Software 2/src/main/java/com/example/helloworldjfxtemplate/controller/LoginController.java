package com.example.helloworldjfxtemplate.controller;
import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author John C Costa SR.
 */

public class LoginController implements Initializable {
    /** UserName Field */
    public TextField userNameField;
    /** Password Field */
    public TextField passwordField;
    /** Sign in Field */
    public Button signIn;
    /** TimeZone Field */
    public Label timeZone;
    /** WGU Label */
    public Label wgu;
    /** Login Label */
    public Label logIn;
    /** UserName Label */
    public Label userName;
    /** Password Label */
    public Label password;


    public void initialize(URL url, ResourceBundle resourceBundle) {
        /** Set for ZoneID */
        LocalDate myLD = LocalDate.of(2020, 10, 11);
        LocalTime myLT = LocalTime.of(22,0);
        LocalDateTime myLDT = LocalDateTime.of(myLD, myLT);
        ZoneId myZoneID = ZoneId.systemDefault();
        ZonedDateTime myZDT = ZonedDateTime.of(myLDT, myZoneID);
        System.out.println("User Time: " + myZDT);

        ZoneId utcZoneId = ZoneId.of("UTC");
        ZonedDateTime utcZDT = ZonedDateTime.ofInstant(myZDT.toInstant(), utcZoneId);
        System.out.println("User Time to UTC: " + utcZDT);
        timeZone.setText(String.valueOf(myZoneID));

        /** Keys for language settings */
       //Locale.setDefault(new Locale("fr"));
        ResourceBundle lang = ResourceBundle.getBundle("Lang", Locale.getDefault());
        wgu.setText(lang.getString("wgu"));
        logIn.setText(lang.getString("logIn"));
        signIn.setText(lang.getString("signIn"));
        userName.setText(lang.getString("userName"));
        password.setText(lang.getString("password"));

        System.out.println("Login Controller Initialized!");
        /*language.getItems().addAll("English", "French");
       if(language.getItems().contains("French")){
       }
        //language.setPromptText("English");
        LocalTime start = LocalTime.of(6,0);
        LocalTime end = LocalTime.of(17,0);
        //setValue(),getValue(), ObservableList<LocalTime>
        //DateTimeFormatter.ofPattern()

        while (start.isBefore(end.plusSeconds(1))){
            timeZone.getItems().add(start);
            start = start.plusMinutes(10);
        }
        timeZone.getSelectionModel().select(LocalTime.of(8,0));
        */

    }
    /** Login - OnAction */
    public void onClickLogIn(ActionEvent event) throws IOException, SQLException {
        String username = userNameField.getText();
        String Password = passwordField.getText();
        boolean validateUser = JDBC.validateLogin(username, Password);
        /** @param content Print to file */
        try {
            PrintWriter pw = new PrintWriter(new FileOutputStream(new File("WriteFile.txt"), true/* append=true */));
            pw.append("User Name: " + username + " | ");
            pw.append("Password: " + Password + " | ");
            pw.append("Time:" + LocalDateTime.now()+ " | ");
            if(validateUser == true){
                pw.append("Valid User! \n");
            }else
                pw.append("Invalid User! \n");
            pw.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MainApplication.class.getName()).log(Level.SEVERE,null,ex);
        }
        if(validateUser){

            Stage stage = (Stage) signIn.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("directoryGUI.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("");
            stage.setScene(scene);
        }else{ MainApplication.popUp("Invalid entry", "Error", "User Name or Password entry does not match.");
        }
    }
}
