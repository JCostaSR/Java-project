package com.example.helloworldjfxtemplate.controller;
import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.appointments;
import com.example.helloworldjfxtemplate.model.contacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author John C Costa SR.
 */

public class ReportsController implements Initializable {

    /** Audit Table */
    public TableView <appointments> auditTable;
    /** Sppointment ID Column */
    public TableColumn <appointments, Integer> appointmentID;
    /** Description Column */
    public TableColumn <appointments, String> description;
    /** Type Column */
    public TableColumn <appointments, String> typeContact;
    /** Customer ID Column */
    public TableColumn <appointments, String> customerID;
    /** Contact ID Column */
    public TableColumn <appointments, Integer> contactID;

    /** Month Combobox */
    public ComboBox monthList;
    /** Type ComboBox */
    public ComboBox typeList;
    /** Contact ComboBox */
    public ComboBox contactReport;

    /** Report Label */
    public Label reports;
    /** Total Customer Label */
    public Label totalCustomers;
    /** Appointments Label */
    public Label appointments;
    /** Contacts Label */
    public Label contactslbl;
    /** Month Filter Label */
    public Label monthFilter;
    /** Month Label */
    public Label monthLbl;
    /** Type Label */
    public Label typeLbl;
    /** Type Filter Label */
    public Label typeFilter;

    /** Return to Directory Button */
    public Button returnGUI;
    /** Count Button */
    public Button setCount;

    /** Variables */
    public int monthTotal = 0;
    public int typeTotal = 0;
    public int Planning = 0;
    public int Briefing = 0;
    public String newType1 = null;
    public String newType2 = null;
    public String newType3 = null;
    public int other1 = 0;
    public int other2 = 0;
    public int other3 = 0;
    public int January = 0;
    public int February = 0;
    public int March = 0;
    public int April = 0;
    public int May = 0;
    public int June = 0;
    public int July = 0;
    public int August = 0;
    public int September = 0;
    public int October = 0;
    public int November = 0;
    public int December = 0;

    /** Return to Directory - OnAction */
    public void onClickReturn(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) returnGUI.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("directoryGUI.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Contact ObservableList */
    ObservableList<appointments> contactsAppointment = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** Populate Month Report Filter */
        {
            try {
                String sql = "SElECT Start FROM appointments";
                PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    LocalDateTime monthNameList = rs.getTimestamp("Start").toLocalDateTime();
                    String newMonthNameList = monthNameList.toString().substring(5, 7);

                    if (newMonthNameList.equals("01")) {
                        if (!newMonthNameList.contains("January")) {
                            newMonthNameList = "January";
                            January++;
                        } else if (newMonthNameList.equals("January"))
                            January++;
                        monthList.getItems().remove("January");
                    } else if (newMonthNameList.equals("02")) {
                        if (!newMonthNameList.contains("February")) {
                            newMonthNameList = "February";
                            February++;
                        } else if (newMonthNameList.equals("February"))
                            February++;
                        monthList.getItems().remove("February");
                    } else if (monthNameList.equals("03")) {
                        if (!newMonthNameList.contains("March")) {
                            newMonthNameList = "March";
                            March++;
                        } else if (newMonthNameList.equals("March"))
                            March++;
                        monthList.getItems().remove("March");
                    } else if (newMonthNameList.equals("04")) {
                        if (!newMonthNameList.contains("April")) {
                            newMonthNameList = "April";
                            April++;
                        } else if (newMonthNameList.equals("April"))
                            April++;
                        monthList.getItems().remove("April");
                    } else if (newMonthNameList.equals("05")) {
                        if (!newMonthNameList.contains("May")) {
                            newMonthNameList = "May";
                            May++;
                        } else if (newMonthNameList.equals("May"))
                        May++;
                        monthList.getItems().remove("May");
                    } else if (newMonthNameList.equals("06")) {
                        if (!newMonthNameList.contains("June")) {
                            newMonthNameList = "June";
                            June++;
                        } else if (newMonthNameList.equals("June"))
                            June++;
                        monthList.getItems().remove("June");
                    } else if (newMonthNameList.equals("07")) {
                        if (!newMonthNameList.contains("July")) {
                            newMonthNameList = "July";
                            July++;
                        } else if (newMonthNameList.equals("July"))
                            July++;
                        monthList.getItems().remove("July");
                    } else if (newMonthNameList.equals("08")) {
                        if (!newMonthNameList.contains("August")) {
                            newMonthNameList = "Auguest";
                            August++;
                        } else if (newMonthNameList.equals("August"))
                            August++;
                        monthList.getItems().remove("August");
                    } else if (newMonthNameList.equals("09")) {
                        if (!newMonthNameList.contains("September")) {
                            newMonthNameList = "September";
                            September++;
                        } else if (newMonthNameList.equals("September"))
                            September++;
                        monthList.getItems().remove("September");
                    } else if (newMonthNameList.equals("10")) {
                        if (!newMonthNameList.contains("October")) {
                            newMonthNameList = "October";
                            October++;
                        } else if (newMonthNameList.equals("October"))
                            October++;
                        monthList.getItems().remove("October");
                    } else if (newMonthNameList.equals("11")) {
                        if (!newMonthNameList.contains("November")) {
                            newMonthNameList = "November";
                            November++;
                        } else if (newMonthNameList.equals("November"))
                            November++;
                        monthList.getItems().remove("November");
                    } else if (newMonthNameList.equals("12")) {
                        if (!newMonthNameList.contains("December")) {
                            newMonthNameList = "December";
                            December++;
                        } else if (newMonthNameList.equals("December"))
                            December++;
                        monthList.getItems().remove("December");
                    }

                    if (monthList != null) {
                        monthList.getItems().add(newMonthNameList);
                    }
                }
                System.out.println(monthList.getItems());
                System.out.println(monthTotal);

            } catch (Exception e) {
                //blank
            }

        }
        /** Populate Type Filter Report */
        try {
            ObservableList<appointments> typeNameList = FXCollections.observableArrayList();
            String sql = "SElECT Type FROM appointments";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            String typeTxT = null;
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                typeTxT = rs.getString("Type");
                if(typeTxT.equals("Planning Session")) {
                    if (!typeList.getItems().toString().contains("Planning Session")) {
                        Planning++;
                        typeList.getItems().add(typeTxT);
                    }else if (typeTxT.toString().equals("Planning Session")) {
                        Planning++;
                    }
                }else if(typeTxT.equals("De-Briefing")) {
                    if (!typeList.getItems().toString().contains("De-Briefing")) {
                        Briefing++;
                        typeList.getItems().add(typeTxT);
                    }else if (typeTxT.toString().equals("De-Briefing")) {
                        Briefing++;
                    }
                } else if (typeTxT.equals(newType1) || !(typeTxT.equals("Planning Session") && typeTxT.equals("De-Briefing") && typeTxT.equals(newType2) && typeTxT.equals(newType3))) {
                    newType1 = typeTxT;

                    if (!typeList.getItems().toString().contains(newType1)) {
                        other1++;
                        typeList.getItems().add(newType1);
                    } else if (typeList.getItems().toString().equals(newType1)) {
                        other1++;
                    }
                } else if (typeTxT.equals(newType2) || !(typeTxT.equals("Planning Session") && typeTxT.equals("De-Briefing") && typeTxT.equals(newType1) && typeTxT.equals(newType3))) {
                    newType2 = typeTxT;

                    if (!typeList.getItems().toString().contains(newType2)) {
                        other2++;
                        typeList.getItems().add(newType2);
                    } else if (typeList.getItems().toString().equals(newType2)) {
                        other2++;
                    }
                } else if (typeTxT.equals(newType3) || !(typeTxT.equals("Planning Session") && typeTxT.equals("De-Briefing") && typeTxT.equals(newType1) && typeTxT.equals(newType2))) {
                    newType3 = typeTxT;

                    if (!typeList.getItems().toString().contains(newType3)) {
                        other3++;
                        typeList.getItems().add(newType3);
                    } else if (typeList.getItems().toString().equals(newType3)) {
                        other3++;
                    }
                }
            }
        } catch (Exception e) {
            //blank
        }

        System.out.println(typeTotal);

        /** Populate Contacts ComboBox */
        try {
            String sql = "SElECT * FROM contacts";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int contactID = 0;
            String contactName = null;
            while (rs.next()) {
                contactID = rs.getInt("Contact_ID");
                if(contactID == 1) {
                    contactReport.getItems().add("Anika Costa");
                }else if(contactID == 2){
                    contactReport.getItems().add("Daniel Garcia");
                }else if (contactID == 3) {
                    contactReport.getItems().add("Li Lee");
                }
            }
            } catch (Exception e) {
            //blank
        }

        /** Populate Conacts Table */
        {
            String sql = "SELECT * FROM appointments";
            try {
                PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    int appointmentID = rs.getInt("Appointment_ID");
                    String description = rs.getString("Description");
                    String typeContact = rs.getString("Type");
                    int customerID = rs.getInt("Customer_ID");
                    int contactID = rs.getInt("Contact_ID");
                    contactsAppointment.add(new appointments(appointmentID, description, typeContact, customerID, contactID));
                }
                appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
                description.setCellValueFactory(new PropertyValueFactory<>("description"));
                typeContact.setCellValueFactory(new PropertyValueFactory<>("type"));
                customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
                contactID.setCellValueFactory(new PropertyValueFactory<>("contactID"));
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
            auditTable.setItems(contactsAppointment);
        }

    }

    /** Type ComboBox Filter */
    // Lambda for Type
    public void typeBox(ActionEvent actionEvent) {

        if (typeList.getValue() != null){
            if (typeList.getValue().equals("De-Briefing")){
                typeTotal = Briefing;
                System.out.println("Briefing: " + Briefing);
            }
            System.out.println(typeTotal);
            if (typeList.getValue().equals("Planning Session")){
                typeTotal = Planning;
                System.out.println("Planning: " + Planning);
            }
            if (typeList.getValue().equals(newType1)){
                typeTotal = other1;
                System.out.println(newType1+": " + other1);
            }
            if (typeList.getValue().equals(newType2)){
                typeTotal = other2;
                System.out.println(newType2+": " + other2);
            }
            if (typeList.getValue().equals(newType3)){
                typeTotal = other3;
                System.out.println(newType3+": " + other3);
            }
        }
        System.out.println("Filtered By Type");
    }

    /** Count Filter */
    public void pullCount(ActionEvent actionEvent) {
        if ((monthList.getValue() == null) && (typeList.getValue() == null)) {
        monthFilter.setText(": " + 0);
        typeFilter.setText(": " + 0);
        }else if (!(monthList.getValue() == null) && (typeList.getValue() == null)) {
            monthFilter.setText(": " + monthTotal);
            typeFilter.setText(": " + 0);
        }else if ((monthList.getValue() == null) && !(typeList.getValue() == null)){
            monthFilter.setText(": " + 0);
            typeFilter.setText(": " + typeTotal);
        }else{
            monthFilter.setText(": " + monthTotal);
            typeFilter.setText(": " + typeTotal);
        }
//        if (typeList.equals(null)){
//            count.setText("Type :" + 0);
//        }

    }

    /** Lambda - Count ComboBox Filter Report*/
    // Shows appointments by contact to see workloads (or lack of). This would help with new customers to fill schedules
    public void contactBox(ActionEvent actionEvent) {
        ObservableList<appointments> filterAppointment = FXCollections.observableArrayList();
        ObservableList<appointments> contactFilter = FXCollections.observableArrayList();

        if (contactReport.getValue().equals("Anika Costa")){
            contactReport.setValue(1);
        }
        if (contactReport.getValue().equals("Daniel Garcia")){
            contactReport.setValue(2);
        }
        if (contactReport.getValue().equals("Li Lee")){
            contactReport.setValue(3);
        }

       contactsAppointment.forEach(a->{
       int contactFilterID = (int) contactReport.getValue();

       System.out.println(contactFilterID);
        a.getContactID();

        if (a.getContactID() == contactFilterID){
            contactFilter.add(a);
        }

    });
                auditTable.setItems(contactFilter);

        System.out.println("Filtered By Contacts");
    }

    /** Month ComboBox Filter */
    public void monthBox(ActionEvent actionEvent) {
        if (monthList != null){
            if (monthList.getValue().equals("January")) {
                monthTotal = January;
            }
            else if (monthList.getValue().equals("February")) {
                monthTotal = February;
            }
            else if (monthList.getValue().equals("March")) {
                monthTotal = March;
            }
            else if (monthList.getValue().equals("April")) {
                monthTotal = April;
            }
            else if (monthList.getValue().equals("May")) {
                monthTotal = May;
            }
            else if (monthList.getValue().equals("June")) {
                monthTotal = June;
            }
            else if (monthList.getValue().equals("July")) {
                monthTotal = July;
            }
            else if (monthList.getValue().equals("August")) {
                monthTotal = August;
            }
            else if (monthList.getValue().equals("September")) {
                monthTotal = September;
            }
            else if (monthList.getValue().equals("October")) {
                monthTotal = October;
            }
            else if (monthList.getValue().equals("November")) {
                monthTotal = November;
            }
            else if (monthList.getValue().equals("December")) {
                monthTotal = December;
            }
        }
        System.out.println(monthTotal + " 1 ");
    }

}

