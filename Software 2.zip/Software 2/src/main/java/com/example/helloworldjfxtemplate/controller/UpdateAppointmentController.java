package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.appointments;
import com.example.helloworldjfxtemplate.model.contacts;
import com.example.helloworldjfxtemplate.model.customers;
import com.example.helloworldjfxtemplate.model.users;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * @author John C Costa SR.
 */

public class UpdateAppointmentController implements Initializable {
    /** Appointment ID Field */
    public TextField appointmentIDTF;
    /** Title Field */
    public TextField titleTF;
    /** Description Field */
    public TextField descriptionTF;
    /** Locaiton Field */
    public TextField locationTF;
    /** Type Field */
    public TextField typeTF;

    /** Contact ComboBox */
    public ComboBox contactBox;
    /** Start Time ComboBox */
    public ComboBox startTimeBox;
    /** End Time ComboBox */
    public ComboBox endTimeBox;
    /** Customer ID ComboBox */
    public ComboBox customerIDBox;
    /** User ID ComboBox */
    public ComboBox userIDBox;

    /** Start Date DatePicker */
    public DatePicker startDatePick;
    /** End Date DatePicker */
    public DatePicker endDatePick;

    /** Save Button */
    public Button save;
    /** Cancel Button */
    public Button cancel;
    /** Update Appointment Label */
    public Label updateAppt;
    /** Appointment ID Label */
    public Label appointmentID;
    /** Title Label */
    public Label title;
    /** Description Label */
    public Label description;
    /** Location Label */
    public Label location;
    /** Contact Label */
    public Label contact;
    /** Type Label */
    public Label type;
    /** Start Time Label */
    public Label startTime;
    /** End Time Label */
    public Label endTime;
    /** Customer ID Label */
    public Label customerID;
    /** User ID Label */
    public Label userID;
    /** Start Date Label */
    public Label startDate;
    /** End Date Label */
    public Label endDate;

    /** Variables */
    public int selectedIndex;
    public int myIndex;
    appointments appts;

    /** Import Data to Fields*/
    public void sendData(int selectedIndex, appointments selectedAppointment){
        appts = selectedAppointment;
        myIndex = selectedIndex;
        this.selectedIndex = selectedIndex;
        appointmentIDTF.setText(String.valueOf(appts.getAppointmentID()));
        titleTF.setText(appts.getTitle());
        descriptionTF.setText(appts.getDescription());
        locationTF.setText(appts.getLocation());
        contactBox.setValue(appts.getContactID());
        startTimeBox.setValue(appts.getStartDateTime().toString().substring(11, 16));
        endTimeBox.setValue(appts.getEndDateTime().toString().substring(11, 16));
        startDatePick.setValue(LocalDate.parse(appts.getStartDateTime().toString().substring(0, 10)));
        endDatePick.setValue(LocalDate.parse(appts.getStartDateTime().toString().substring(0, 10)));
        typeTF.setText(appts.getType());
        customerIDBox.setValue(appts.getCustomerID());
        userIDBox.setValue(appts.getUserID());

    }

    /** Save - OnAction */
    public void onClickSaveUpdateAppointment(ActionEvent actionEvent) throws IOException, SQLException {

        try {
            int apppointmentIDField = Integer.parseInt(appointmentIDTF.getText());

            String titleField = titleTF.getText();
            if (titleTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Title and all other fields");
                return;
            }
            String descriptionField = descriptionTF.getText();
            if (descriptionTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Description and all other fields");
                return;
            }
            String locationField = locationTF.getText();
            if (locationTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Location and all other fields");
                return;
            }
            String typeField = typeTF.getText();
            if (typeTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Type and all other fields");
                return;
            }
            if(contactBox.getValue() == null){
                MainApplication.confirmPopUp("Input Error", "No contact selected, please select a contact");
                return;
            }
            if (!(startDatePick.getValue().equals(endDatePick.getValue()))){
                MainApplication.confirmPopUp("Input Error", "Appointment start and end are on separate days, must be the same day.");
                return;
            }
            if (startTimeBox.getValue().equals(endTimeBox.getValue())){
                MainApplication.confirmPopUp("Input Error", "Appointment start and end time are set to the same time.");
                return;
            }
            LocalTime sStartTime = LocalTime.parse(startTimeBox.getValue().toString());
            LocalTime sEndTime = LocalTime.parse(endTimeBox.getValue().toString());
            if (sStartTime.isAfter(sEndTime)){
                MainApplication.confirmPopUp("Input Error", "Appointment start time is after the requested end time.");
                return;
            }
           // System.out.println(sEndTime);
            if(customerIDBox.getValue() == null){
                MainApplication.confirmPopUp("Input Error", "No Customer ID selected, please select a Customer ID");
                return;
            }
            if(userIDBox.getValue() == null){
                MainApplication.confirmPopUp("Input Error", "No User ID selected, please select a User ID");
                return;
            }

            int contactField =  Integer.parseInt(String.valueOf(contactBox.getValue()));
            LocalDateTime startDateTime = LocalDateTime.of(startDatePick.getValue(), LocalTime.parse(startTimeBox.getValue().toString()));
            LocalDateTime endDateTime = LocalDateTime.of(endDatePick.getValue(), LocalTime.parse(endTimeBox.getValue().toString()));
            int customerIDField = Integer.parseInt(String.valueOf(customerIDBox.getValue()));
            int userIDField = Integer.parseInt(String.valueOf(userIDBox.getValue()));
            System.out.println(contactField);
            System.out.println(startDateTime);
            System.out.println(endDateTime);
            System.out.println(customerIDField);
            System.out.println(userIDField);


            LocalDateTime lastUpdate = LocalDateTime.now();
            String lastUpdatedBy = "script";

            JDBC.makeConnection();
            int rowsAffected = QueryManager.updateAppointment(apppointmentIDField, titleField, descriptionField, locationField, typeField, startDateTime, endDateTime, lastUpdate, lastUpdatedBy, customerIDField, userIDField, contactField);

            if (rowsAffected > 0) {
                System.out.println("Selected Update Successful!");
            } else {
                System.out.println("Selected Update Failure!");
            }

        }catch(Exception e){
            MainApplication.confirmPopUp("Input Error", "Check fields for correct input entry");
            return;
        }
        Stage stage = (Stage) save.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("appointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);

    }

    /** Update - OnAction */
    public void onClickCancelUpdateAppointment(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) cancel.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("appointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        /** Populate Contacts ComboBox*/
        try {
            String sql = "SElECT * FROM contacts";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int contactIDTxt = 0;
            while (rs.next()) {
                contactIDTxt = rs.getInt("Contact_ID");
                contactBox.getItems().addAll(contactIDTxt);
            }
        }catch (Exception e){
            //blank
        }

        /** Populate Customers ComboBox */
        try {
            String sql = "SElECT * FROM customers";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int customerIDtxt = 0;
            while (rs.next()) {
                customerIDtxt = rs.getInt("Customer_ID");
                customerIDBox.getItems().addAll(customerIDtxt);
            }
        }catch (Exception e){
            //blank}
        }

        /** Populate Users ComboBox */
        try {
            String sql = "SElECT * FROM users";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int userIDtxt = 0;
            while (rs.next()) {
                userIDtxt = rs.getInt("User_ID");
                userIDBox.getItems().addAll(userIDtxt);
            }
        }catch (Exception e){
            //blank}
        }

        /** Populate Start and End ComboBoxes */
        LocalTime start = LocalTime.of(6, 0);
        LocalTime end = LocalTime.of(17, 0);
        while (start.isBefore(end.plusSeconds(1))) {
            startTimeBox.getItems().add(start);
            start = start.plusMinutes(15);
            startTimeBox.getSelectionModel().select(LocalTime.of(10, 0));
            endTimeBox.getItems().add(start);
            endTimeBox.getSelectionModel().select(LocalTime.of(10, 0));
        }




        System.out.println("Update Appointment Controller Initialized!");
    }
}
