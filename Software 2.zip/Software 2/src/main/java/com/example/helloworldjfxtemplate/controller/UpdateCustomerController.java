package com.example.helloworldjfxtemplate.controller;

import com.example.helloworldjfxtemplate.MainApplication;
import com.example.helloworldjfxtemplate.helper.JDBC;
import com.example.helloworldjfxtemplate.helper.QueryManager;
import com.example.helloworldjfxtemplate.model.customers;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * @author John C Costa SR.
 */


public class UpdateCustomerController implements Initializable {

    /** Customer ID Field */
    public TextField customerIDTF;
    /** Address Field */
    public TextField addressTF;
    /** Postal Code */
    public TextField postalCodeTF;
    /** Phone Number */
    public TextField phoneNumberTF;
    /** Customer First Name */
    public TextField customerFirstNameTF;
    /** Customer Last Name */
    public TextField customerLastNameTF;

    /** Save Button */
    public Button save;
    /** Cancel Button */
    public Button cancel;

    /** Update Customer Label */
    public Label updateCustomer;
    /** Customer ID Label */
    public Label customerID;
    /** State or Provence Label */
    public Label stateProvence;
    /** Country Label */
    public Label country;
    /** Postal Code Label */
    public Label postalCode;
    /** Phone Number */
    public Label phoneNumber;
    /** Customer Fist Name Label */
    public Label customerFirstName;
    /** Customer Last Name Label */
    public Label customerLastName;
    /** Address Label */
    public Label address;

    /** State or Provence ComboBox */
    public ComboBox stateProvenceBox;
    /** Country ComboBox */
    public ComboBox countryBox;

    /** Variables */
    public int selectedIndex;
    public int myIndex;
    customers customer;
    public int divisionId = 0;

    /** Import Data to Populate Fields */
    public void sendCustomerData(int selectedIndex, customers selectedCustomer){
        customer = selectedCustomer;
        myIndex = selectedIndex;
        this.selectedIndex = selectedIndex;
        customerIDTF.setText(String.valueOf(customer.getCustomerID()));
        customerFirstNameTF.setText(customer.getCustomerName().substring(0, Integer.parseInt(String.valueOf(customer.getCustomerName().indexOf(" ", 0)))));
        customerLastNameTF.setText(customer.getCustomerName().substring(Integer.parseInt(String.valueOf(customer.getCustomerName().indexOf(" ", 0)+1)), customer.getCustomerName().length()));
        addressTF.setText(customer.getAddress());
        postalCodeTF.setText(String.valueOf(customer.getPostalCode()));
        phoneNumberTF.setText(String.valueOf(customer.getPhoneNumber()));
        //countryBox.setValue("U.S");
        System.out.println(customer.getCustomerID());
        try {
            String sql = "SElECT * FROM customers";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int customerId = 0;
            String divisontxt = null;
            int divisionId = 0;
            while (rs.next()) {
                customerId = rs.getInt("Customer_ID");
                divisionId = rs.getInt("Division_ID");
                if(customer.getCustomerID() == customerId) {
                    if (divisionId <= 54) {
                        countryBox.setValue("U.S");
                    }
                    if (divisionId >= 60 && divisionId <= 72) {
                        countryBox.setValue("Canada");
                    }
                    if (divisionId >= 101 && divisionId <= 104) {
                        countryBox.setValue("UK");
                    }
                    if (divisionId == 1) {
                        stateProvenceBox.setValue("Alabama");
                    } else if (divisionId == 2) {
                        stateProvenceBox.setValue("Arizona");
                    } else if (divisionId == 3) {
                        stateProvenceBox.setValue("Arkansas");
                    } else if (divisionId == 4) {
                        stateProvenceBox.setValue("California");
                    } else if (divisionId == 5) {
                        stateProvenceBox.setValue("California");
                    } else if (divisionId == 6) {
                        stateProvenceBox.setValue("Connecticut");
                    } else if (divisionId == 7) {
                        stateProvenceBox.setValue("Delaware");
                    } else if (divisionId == 8) {
                        stateProvenceBox.setValue("District of Columbia");
                    } else if (divisionId == 9) {
                        stateProvenceBox.setValue("Florida");
                    } else if (divisionId == 10) {
                        stateProvenceBox.setValue("Georgia");
                    } else if (divisionId == 11) {
                        stateProvenceBox.setValue("Idaho");
                    } else if (divisionId == 12) {
                        stateProvenceBox.setValue("Illinois");
                    } else if (divisionId == 13) {
                        stateProvenceBox.setValue("Indiana");
                    } else if (divisionId == 14) {
                        stateProvenceBox.setValue("Iowa");
                    } else if (divisionId == 15) {
                        stateProvenceBox.setValue("Kansas");
                    } else if (divisionId == 16) {
                        stateProvenceBox.setValue("Kentucky");
                    } else if (divisionId == 17) {
                        stateProvenceBox.setValue("Louisiana");
                    } else if (divisionId == 18) {
                        stateProvenceBox.setValue("Maine");
                    } else if (divisionId == 19) {
                        stateProvenceBox.setValue("Maryland");
                    } else if (divisionId == 20) {
                        stateProvenceBox.setValue("Massachusetts");
                    } else if (divisionId == 21) {
                        stateProvenceBox.setValue("Michigan");
                    } else if (divisionId == 22) {
                        stateProvenceBox.setValue("Minnesota");
                    } else if (divisionId == 23) {
                        stateProvenceBox.setValue("Mississippi");
                    } else if (divisionId == 24) {
                        stateProvenceBox.setValue("Missouri");
                    } else if (divisionId == 25) {
                        stateProvenceBox.setValue("Montana");
                    } else if (divisionId == 26) {
                        stateProvenceBox.setValue("Nebraska");
                    } else if (divisionId == 27) {
                        stateProvenceBox.setValue("Nevada");
                    } else if (divisionId == 28) {
                        stateProvenceBox.setValue("New Hampshire");
                    } else if (divisionId == 29) {
                        stateProvenceBox.setValue("New Jersey");
                    } else if (divisionId == 30) {
                        stateProvenceBox.setValue("New Mexico");
                    } else if (divisionId == 31) {
                        stateProvenceBox.setValue("New York");
                    } else if (divisionId == 32) {
                        stateProvenceBox.setValue("North Carolina");
                    } else if (divisionId == 33) {
                        stateProvenceBox.setValue("North Dakota");
                    } else if (divisionId == 34) {
                        stateProvenceBox.setValue("Ohio");
                    } else if (divisionId == 35) {
                        stateProvenceBox.setValue("Oklahoma");
                    } else if (divisionId == 36) {
                        stateProvenceBox.setValue("Oregon");
                    } else if (divisionId == 37) {
                        stateProvenceBox.setValue("Pennsylvania");
                    } else if (divisionId == 38) {
                        stateProvenceBox.setValue("Rhode Island");
                    } else if (divisionId == 39) {
                        stateProvenceBox.setValue("South Carolina");
                    } else if (divisionId == 40) {
                        stateProvenceBox.setValue("South Dakota");
                    } else if (divisionId == 41) {
                        stateProvenceBox.setValue("Tennessee");
                    } else if (divisionId == 42) {
                        stateProvenceBox.setValue("Texas");
                    } else if (divisionId == 43) {
                        stateProvenceBox.setValue("Utah");
                    } else if (divisionId == 44) {
                        stateProvenceBox.setValue("Vermont");
                    } else if (divisionId == 45) {
                        stateProvenceBox.setValue("Virginia");
                    } else if (divisionId == 46) {
                        stateProvenceBox.setValue("Washington");
                    } else if (divisionId == 47) {
                        stateProvenceBox.setValue("West Virginia");
                    } else if (divisionId == 48) {
                        stateProvenceBox.setValue("Wisconsin");
                    } else if (divisionId == 49) {
                        stateProvenceBox.setValue("Wyoming");
                    } else if (divisionId == 52) {
                        stateProvenceBox.setValue("Hawaii");
                    } else if (divisionId == 54) {
                        stateProvenceBox.setValue("Alaska");
                    } else if (divisionId == 60) {
                        stateProvenceBox.setValue("Northwest Territories");
                    } else if (divisionId == 61) {
                        stateProvenceBox.setValue("Alberta");
                    } else if (divisionId == 62) {
                        stateProvenceBox.setValue("British Columbia");
                    } else if (divisionId == 63) {
                        stateProvenceBox.setValue("Manitoba");
                    } else if (divisionId == 64) {
                        stateProvenceBox.setValue("New Brunswick");
                    } else if (divisionId == 65) {
                        stateProvenceBox.setValue("Nova Scotia");
                    } else if (divisionId == 66) {
                        stateProvenceBox.setValue("Prince Edward Island");
                    } else if (divisionId == 67) {
                        stateProvenceBox.setValue("Ontario");
                    } else if (divisionId == 68) {
                        stateProvenceBox.setValue("Québec");
                    } else if (divisionId == 69) {
                        stateProvenceBox.setValue("Saskatchewan");
                    } else if (divisionId == 70) {
                        stateProvenceBox.setValue("Nunavut");
                    } else if (divisionId == 71) {
                        stateProvenceBox.setValue("Yukon");
                    } else if (divisionId == 72) {
                        stateProvenceBox.setValue("Newfoundland and Labrador");
                    } else if (divisionId == 101) {
                        stateProvenceBox.setValue("England");
                    } else if (divisionId == 102) {
                        stateProvenceBox.setValue("Wales");
                    } else if (divisionId == 103) {
                        stateProvenceBox.setValue("Scotland");
                    } else if (divisionId == 104) {
                        stateProvenceBox.setValue("Northern Ireland");
                    }
                }
            }
            System.out.println(customerId);
        } catch (Exception e) {
            //blank
        }

    }

    /** Save - OnAction */
    public void onClickSaveUpdateCustomer(ActionEvent actionEvent) throws IOException {

        try {
            int customerIDField = Integer.parseInt(customerIDTF.getText());
            if (customerFirstNameTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Customer Name and all other fields");
                return;
            }
            if (customerLastNameTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Customer Name and all other fields");
                return;
            }
            String customerNameField = customerFirstNameTF.getText() + " " + customerLastNameTF.getText();
            String addressField = addressTF.getText();
            if (addressTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Address and all other fields");
                return;
            }
            String postalCodeField = postalCodeTF.getText();
            if (postalCodeTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Postal Code and all other fields");
                return;
            }

            String phoneNumberField = phoneNumberTF.getText();
            if (phoneNumberTF.getText().isEmpty()) {
                MainApplication.confirmPopUp("Input Error", "Blank Field(s) Detected, please check Phone Number and all other fields");
                return;
            }
            if(countryBox.getItems().isEmpty()){
                MainApplication.confirmPopUp("Input Error", "No Country selected, please Select a Country.");
                return;
            }
            if(stateProvenceBox.getItems().isEmpty()){
                MainApplication.confirmPopUp("Input Error", "No State or Provence was selected, please select a State or Provence. (A country must also be provided for this listing)");
                return;
            }
            if(stateProvenceBox.getValue().equals("Alabama")){
                divisionId = 1;
            }
            else if(stateProvenceBox.getValue().equals("Arizona")){
                divisionId = 2;
            }
            else if(stateProvenceBox.getValue().equals("Arkansas")){
                divisionId = 3;
            }
            else if(stateProvenceBox.getValue().equals("California")){
                divisionId = 4;
            }
            else if(stateProvenceBox.getValue().equals("Colorado")){
                divisionId = 5;
            }
            else if(stateProvenceBox.getValue().equals("Connecticut")){
                divisionId = 6;
            }
            else if(stateProvenceBox.getValue().equals("Delaware")){
                divisionId = 7;
            }
            else if(stateProvenceBox.getValue().equals("District of Columbia")){
                divisionId = 8;
            }
            else if(stateProvenceBox.getValue().equals("Florida")){
                divisionId = 9;
            }
            else if(stateProvenceBox.getValue().equals("Georgia")){
                divisionId = 10;
            }
            else if(stateProvenceBox.getValue().equals("Idaho")){
                divisionId = 11;
            }
            else if(stateProvenceBox.getValue().equals("Illinois")){
                divisionId = 12;
            }
            else if(stateProvenceBox.getValue().equals("Indiana")){
                divisionId = 13;
            }
            else if(stateProvenceBox.getValue().equals("Iowa")){
                divisionId = 14;
            }
            else if(stateProvenceBox.getValue().equals("Kansas")){
                divisionId = 15;
            }
            else if(stateProvenceBox.getValue().equals("Kentucky")){
                divisionId = 16;
            }
            else if(stateProvenceBox.getValue().equals("Louisiana")){
                divisionId = 17;
            }
            else if(stateProvenceBox.getValue().equals("Maine")){
                divisionId = 18;
            }
            else if(stateProvenceBox.getValue().equals("Maryland")){
                divisionId = 19;
            }
            else if(stateProvenceBox.getValue().equals("Massachusetts")){
                divisionId = 20;
            }
            else if(stateProvenceBox.getValue().equals("Michigan")){
                divisionId = 21;
            }
            else if(stateProvenceBox.getValue().equals("Minnesota")){
                divisionId = 22;
            }
            else if(stateProvenceBox.getValue().equals("Mississippi")){
                divisionId = 23;
            }
            else if(stateProvenceBox.getValue().equals("Missouri")){
                divisionId = 24;
            }
            else if(stateProvenceBox.getValue().equals("Montana")){
                divisionId = 25;
            }
            else if(stateProvenceBox.getValue().equals("Nebraska")){
                divisionId = 26;
            }
            else if(stateProvenceBox.getValue().equals("Nevada")){
                divisionId = 27;
            }
            else if(stateProvenceBox.getValue().equals("New Hampshire")){
                divisionId = 28;
            }
            else if(stateProvenceBox.getValue().equals("New Jersey")){
                divisionId = 29;
            }
            else if(stateProvenceBox.getValue().equals("New Mexico")){
                divisionId = 30;
            }
            else if(stateProvenceBox.getValue().equals("New York")){
                divisionId = 31;
            }
            else if(stateProvenceBox.getValue().equals("North Carolina")){
                divisionId = 32;
            }
            else if(stateProvenceBox.getValue().equals("North Dakota")){
                divisionId = 33;
            }
            else if(stateProvenceBox.getValue().equals("Ohio")){
                divisionId = 34;
            }
            else if(stateProvenceBox.getValue().equals("Oklahoma")){
                divisionId = 35;
            }
            else if(stateProvenceBox.getValue().equals("Oregon")){
                divisionId = 36;
            }
            else if(stateProvenceBox.getValue().equals("Pennsylvania")){
                divisionId = 37;
            }
            else if(stateProvenceBox.getValue().equals("Rhode Island")) {
                divisionId = 38;
            }
            else if(stateProvenceBox.getValue().equals("South Carolina")){
                divisionId = 39;
            }
            else if(stateProvenceBox.getValue().equals("South Dakota")){
                divisionId = 40;
            }
            else if(stateProvenceBox.getValue().equals("Tennessee")){
                divisionId = 41;
            }
            else if(stateProvenceBox.getValue().equals("Texas")){
                divisionId = 42;
            }
            else if(stateProvenceBox.getValue().equals("Utah")){
                divisionId = 43;
            }
            else if(stateProvenceBox.getValue().equals("Vermont")){
                divisionId = 44;
            }
            else if(stateProvenceBox.getValue().equals("Virginia")){
                divisionId = 45;
            }
            else if(stateProvenceBox.getValue().equals("Washington")){
                divisionId = 46;
            }
            else if(stateProvenceBox.getValue().equals("West Virginia")){
                divisionId = 47;
            }
            else if(stateProvenceBox.getValue().equals("Wisconsin")){
                divisionId = 48;
            }
            else if(stateProvenceBox.getValue().equals("Wyoming")){
                divisionId = 49;
            }
            else if(stateProvenceBox.getValue().equals("Hawaii")){
                divisionId = 52;
            }
            else if(stateProvenceBox.getValue().equals("Alaska")){
                divisionId = 54;
            }
            else if(stateProvenceBox.getValue().equals("Northwest Territories")){
                divisionId = 60;
            }
            else if(stateProvenceBox.getValue().equals("Alberta")){
                divisionId = 61;
            }
            else if(stateProvenceBox.getValue().equals("British Columbia")){
                divisionId = 62;
            }
            else if(stateProvenceBox.getValue().equals("Manitoba")){
                divisionId = 63;
            }
            else if(stateProvenceBox.getValue().equals("New Brunswick")){
                divisionId = 64;
            }
            else if(stateProvenceBox.getValue().equals("Nova Scotia")){
                divisionId = 65;
            }
            else if(stateProvenceBox.getValue().equals("Prince Edward Island")){
                divisionId = 66;
            }
            else if(stateProvenceBox.getValue().equals("Ontario")){
                divisionId = 67;
            }
            else if(stateProvenceBox.getValue().equals("Québec")){
                divisionId = 68;
            }
            else if(stateProvenceBox.getValue().equals("Saskatchewan")){
                divisionId = 69;
            }
            else if(stateProvenceBox.getValue().equals("Nunavut")){
                divisionId = 70;
            }
            else if(stateProvenceBox.getValue().equals("Yukon")){
                divisionId = 71;
            }
            else if(stateProvenceBox.getValue().equals("Newfoundland and Labrador")) {
                divisionId = 72;
            }
            else if(stateProvenceBox.getValue().equals("England")){
                divisionId = 101;
            }
            else if(stateProvenceBox.getValue().equals("Wales")){
                divisionId = 102;
            }
            else if(stateProvenceBox.getValue().equals("Scotland")){
                divisionId = 103;
            }
            else if(stateProvenceBox.getValue().equals("Northern Ireland")){
                divisionId = 104;
            }

            LocalDateTime lastUpdate = LocalDateTime.now();
            String lastUpdatedBy = "script";

                    JDBC.makeConnection();
            int rowsAffected = QueryManager.updateCustomer(customerIDField,customerNameField, addressField, postalCodeField, phoneNumberField, lastUpdate, lastUpdatedBy, divisionId);

            if (rowsAffected > 0) {
                System.out.println("Selected Update Successful!");
            } else {
                System.out.println("Selected Update Failure!");
            }

        }catch (Exception e) {
            MainApplication.confirmPopUp("Input Error", "Check fields for correct input entry");
            return;
        }
        Stage stage = (Stage) save.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    /** Cancel - OnAction */
    public void onClickCancelUpdateCustomer(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) cancel.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customer.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("");
        stage.setScene(scene);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        /** County ComboBox Listener */
        countryBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            int divisionID = 0;
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                if (countryBox.getValue().toString().equals("U.S")) { // division ID 1 - 72, country ID 1
                    try {
                        String sql = "SElECT * FROM first_level_divisions";
                        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();

                        String divisontxt = null;
                        int countryIDtxt = 0;
                        while (rs.next()) {
                            divisionID = rs.getInt("Division_ID");
                            divisontxt = rs.getString("Division");
                            countryIDtxt = rs.getInt("Country_ID");
                            if(countryIDtxt == 1) {
                                stateProvenceBox.getItems().addAll(divisontxt);
                            }
                            else if (countryIDtxt != 1) {

                                stateProvenceBox.getItems().remove(divisontxt);
                            }
                        }

                    } catch (Exception e) {
                        //blank
                    }
                    System.out.println(stateProvenceBox.getValue());


                    System.out.println("U.S");
                }else if (countryBox.getValue().toString().equals("UK")) { // division ID 1 - 72, country ID 1
                    //Stream<T> filter(Predicate<? super T> predicate)
                    try {
                        String sql = "SElECT * FROM first_level_divisions";
                        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        String divisontxt = null;
                        int countryIDtxt = 0;
                        while (rs.next()) {
                            divisionID = rs.getInt("Division_ID");
                            divisontxt = rs.getString("Division");
                            countryIDtxt = rs.getInt("Country_ID");
                            if (countryIDtxt == 2) {
                                stateProvenceBox.getItems().add(divisontxt);
                            }
                            if (countryIDtxt != 2) {

                                stateProvenceBox.getItems().remove(divisontxt);
                            }
                        }
                    } catch (Exception e) {
                        //blank
                    }
                    System.out.println(divisionID);

                    System.out.println("U.K");
                }else if (countryBox.getValue().equals("Canada")) { // division ID 1 - 72, country ID 1
                    try {
                        String sql = "SElECT * FROM first_level_divisions";
                        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        String divisontxt = null;
                        int countryIDtxt = 0;
                        while (rs.next()) {
                            divisionID = rs.getInt("Division_ID");
                            divisontxt = rs.getString("Division");
                            countryIDtxt = rs.getInt("Country_ID");
                            if(countryIDtxt == 3) {
                                stateProvenceBox.getItems().add(divisontxt);
                            }
                            if (countryIDtxt != 3) {

                                stateProvenceBox.getItems().remove(divisontxt);
                            }
                        }
                        divisionId = stateProvenceBox.getValue().toString().indexOf(" ",0);
                        System.out.println(divisionID);
                    } catch (Exception e) {
                        //blank
                    }

                    //System.out.println("Canada");
                }
                divisionId = divisionID;
            }
        });


        /** Populate Countries ComboBox */
        try {
            String sql = "SElECT * FROM countries";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            String countrytxt = null;
            while (rs.next()) {
                countrytxt = rs.getString("Country");
                countryBox.getItems().addAll(countrytxt);
            }
        }catch (Exception e){
            //blank
        }
        System.out.println("Update Customer Controller Initialized!");
    }
}
