package com.example.helloworldjfxtemplate.helper;

import java.sql.*;

public abstract class JDBC {
    /** Protocol */
    private static final String protocol = "jdbc";
    /** Vendor */
    private static final String vendor = ":mysql:";
    /** Location */
    private static final String location = "//localhost/";
    /** Database Name */
    private static final String databaseName = "IMS";
    /** Java Database Connection URL */
    private static final String jdbcUrl = protocol + vendor + location + databaseName + "?connectionTimeZone = SERVER"; // LOCAL
    /** Driver */
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    /** UserName */
    private static final String userName = "root";
    /** Password */
    private static String password = "Darkwolf1!";
    /** Connection */
    public static Connection connection;
    /** PreparedStatement */
    private static PreparedStatement preparedStatement;
    /** Connection Status */
    public static String connectionStatus;
    /** Make Connection */
    public static void makeConnection() {
        try {
            Class.forName(driver); // Locate Driver
            connection = DriverManager.getConnection(jdbcUrl, userName, password); // reference Connection object
            connectionStatus = "Database Connection successful!";
        }
        catch(ClassNotFoundException e) {
            System.out.println("Error:" + e.getMessage());
        }
        catch(SQLException e) {
            System.out.println("Error:" + e.getMessage());
        }
    }

    /** Close Connection */
    public static void closeConnection() {
        try {
            connection.close();
            connectionStatus = "Database Connection closed!";
            System.out.println(connectionStatus);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /** @return validateLogin */
    public static boolean validateLogin(String username, String password) throws SQLException {

        String sql = "SElECT * FROM users";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        Object valid = null;
        String USRName = null;
        String Password = null;
        while (rs.next()) {
            USRName = rs.getString("User_Name");
            Password = rs.getString("Password");
            if (USRName.equals(username) && Password.equals(password))
                return true;
        }return true;
    }
}