package com.example.helloworldjfxtemplate.helper;

import com.example.helloworldjfxtemplate.model.appointments;
import com.example.helloworldjfxtemplate.model.customers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;

/**
 * @author John C Costa SR.
 */

public class QueryManager {
    /** Update Tables */
    public  static void updateTables(){
        JDBC.makeConnection();
    }

    // ----------- Appointments ---------------
    /** Insert Appointment Query */
    public static int insertAppointment(int appointmentID, String title, String description, String location, String type, Timestamp startDateTime, Timestamp endDateTime, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String lastUpdatedBy, int customerID, int userID, int contactID) throws SQLException {
        String sql = "INSERT INTO appointments (Appointment_ID, Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, appointmentID);
        ps.setString(2, title);
        ps.setString(3, description);
        ps.setString(4, location);
        ps.setString(5, type);
        ps.setTimestamp(6,startDateTime);
        ps.setTimestamp(7, endDateTime);
        ps.setTimestamp(8, Timestamp.valueOf(createDate));
        ps.setString(9, createdBy);
        ps.setTimestamp(10, Timestamp.valueOf(lastUpdate));
        ps.setString(11, lastUpdatedBy);
        ps.setInt(12, customerID);
        ps.setInt(13, userID);
        ps.setInt(14, contactID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Update Appointment Query */
    public static int updateAppointment(int appointmentID, String title, String description, String location, String type, LocalDateTime startDateTime, LocalDateTime endDateTime, LocalDateTime lastUpdate, String lastUpdatedBy, int customerID, int userID, int contactID) throws SQLException {
        String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Last_Update = ?, Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, title);
        ps.setString(2, description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setTimestamp(5, Timestamp.valueOf(startDateTime));
        ps.setTimestamp(6, Timestamp.valueOf(endDateTime));
        ps.setTimestamp(7, Timestamp.valueOf(lastUpdate));
        ps.setString(8, lastUpdatedBy);
        ps.setInt(9, customerID);
        ps.setInt(10, userID);
        ps.setInt(11, contactID);
        ps.setInt(12, appointmentID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Delete Appointment Query */
    public static int deleteAppointment(int appointmentID) throws SQLException {
        String sql = "DELETE FROM appointments WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, appointmentID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Select Appointment Query */
    public static ObservableList<appointments> selectAppointment() throws SQLException {
        String sql = "SELECT Appointment_ID, Title, Description, Location, Contact_ID, Type, Start, End, Customer_ID, User_ID FROM appointments";
        ObservableList<appointments> appointmentsObservableList = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Integer appointmentIDField = rs.getInt("Appointment_ID");
                String titleField = rs.getString("Title");
                String descriptionField = rs.getString("Description");
                String locationField = rs.getString("Location");
                int contactField = rs.getInt("Contact_ID");
                String typeField = rs.getString("Type");
                LocalDateTime startDateTimeField = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime endDateTimeField = rs.getTimestamp("End").toLocalDateTime();
                int customerIDField = rs.getInt("Customer_ID");
                String userIDField = rs.getString("User_ID");

                appointmentsObservableList.add(new appointments(appointmentIDField, titleField, descriptionField, locationField, contactField, typeField,
                        startDateTimeField, endDateTimeField, customerIDField, userIDField));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return appointmentsObservableList;
    }

    // ----------- Customers ---------------
    /** Insert Customer Query */
    public static int insertCustomer( String customerName, String address, String postalCode, String phoneNumber, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String lastUpdatedBy, int divisionID) throws SQLException {
        String sql = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setString(1, customerName);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phoneNumber);
        ps.setTimestamp(5, Timestamp.valueOf(createDate));
        ps.setString(6, createdBy);
        ps.setTimestamp(7, Timestamp.valueOf(lastUpdate));
        ps.setString(8, lastUpdatedBy);
        ps.setInt(9, divisionID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Update Customer Query */
    public static int updateCustomer(int customerID, String customerName, String address, String postalCode, String phoneNumber, LocalDateTime lastUpdate, String lastUpdatedBy, int divisionId) throws SQLException {
        String sql = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Last_Update = ?, Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, customerName);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phoneNumber);
        ps.setTimestamp(5, Timestamp.valueOf(lastUpdate));
        ps.setString(6, lastUpdatedBy);
        ps.setInt(7, divisionId);
        ps.setInt(8, customerID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Delete Customer Query */
    public static int deleteCustomer(int customerID) throws SQLException {
        String sql = "DELETE FROM customers WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, customerID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Select Customer Query */
    public static ObservableList<customers> selectCustomer() throws SQLException {
        String sql = "SELECT Customer_ID, Customer_Name, Address, Postal_Code, Phone FROM customers";
        ObservableList<customers> customersObservableList = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int customerIDField = rs.getInt(1);
                String customerNameField = rs.getString(2);
                String addressField = rs.getString(3);
                String postalCodeField = rs.getString(4);
                String phoneNumberField = rs.getString(5);
                customersObservableList.add(new customers(customerIDField, customerNameField, addressField, postalCodeField, phoneNumberField));
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }return customersObservableList;
    }

    // ----------- Contacts ---------------
    /** Insert Contacts Query */
    public static int insertConacts(int contactID, String contactName, String email) throws SQLException {
        String sql = "INSERT INTO contacts (Contact_ID, Contact_Name, Email) VALUES(?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, contactID);
        ps.setString(2, contactName);
        ps.setString(3, email);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Update Contacts Query */
    public static int updateContacts(int contactID, String contactName, String email) throws SQLException {
        String sql = "UPDATE contacts SET Contact_Name = ?, Email = ? WHERE Contact_ID ?) VALUES(?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, contactID);
        ps.setString(2, contactName);
        ps.setString(3, email);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Delete Contacts Query */
    public static int deleteContact(int contactID) throws SQLException {
        String sql = "DELETE FROM contacts WHERE Contact_ID ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, contactID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Select Contacts Query */
    public static void selectContact() throws SQLException {
        String sql = "SElECT * FROM contacts";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int contactID = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            String email = rs.getString("Email");

            System.out.print(contactID + " | ");
            System.out.print(contactName + " | ");
            System.out.println(email);
        }
    }

    // ----------- Countries ---------------
    /** Insert Countries Query */
    public static int insertCountries(int countryID, String country, LocalTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdatedBy) throws SQLException {
        String sql = "INSERT INTO countries (Country_ID, Country, Create_Date, Created_By, Last_Update, Last_Updated_By) VALUES(?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, countryID);
        ps.setString(2, country);
        ps.setObject(3, createDate);
        ps.setString(4, createdBy);
        ps.setObject(5, lastUpdate);
        ps.setString(6, lastUpdatedBy);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Update Countries Query */
    public static int updateCountries(int countryID, String country, LocalTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdatedBy) throws SQLException {
        String sql = "UPDATE countries SET Country = ?, Create_Date = ?, Created_By = ?, Last_Update = ?, Last_Updated_By = ? WHERE Country_ID ?) VALUES(?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, countryID);
        ps.setString(2, country);
        ps.setObject(3, createDate);
        ps.setString(4, createdBy);
        ps.setObject(5, lastUpdate);
        ps.setString(6, lastUpdatedBy);

        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Delete Countries Query */
    public static int deleteCountries(int countryID) throws SQLException {
        String sql = "DELETE FROM countries WHERE Country_ID ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, countryID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Select Countries Query */
    public static void selectCountries() throws SQLException {
        String sql = "SElECT * FROM countries";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int countryID = rs.getInt("Country_ID");
            String country = rs.getString("Country");
            Object createDate = rs.getObject("Create_Date");
            String createdBy = rs.getString("Created_By");
            Object lastUpdate = rs.getObject("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");

            System.out.print(countryID + " | ");
            System.out.print(country + " | ");
            System.out.print(createDate + " | ");
            System.out.print(createdBy + " | ");
            System.out.print(lastUpdate + " | ");
            System.out.println(lastUpdatedBy);

        }
    }

    // ----------- First level divisions ---------------
    /** Insert First Level Division Query */
    public static int insertFirstLevelDivisions(int divisionID, String division, LocalTime createDate, String createBy, ZonedDateTime lastUpdate, String lastUpdatedBy, int countryID) throws SQLException {
        String sql = "INSERT INTO first_level_divisions (Division_ID, Division, Create_Date, Created_By, Last_Update, Last_Updated_By, Country_ID) VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, divisionID);
        ps.setString(2, division);
        ps.setObject(3, createDate);
        ps.setString(4, createBy);
        ps.setObject(5, lastUpdate);
        ps.setString(6, lastUpdatedBy);
        ps.setInt(7,countryID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Update First Level Division Query */
    public static int updateFirstLevelDivisions(int divisionID, String divsion, LocalTime createDate, String createBy, ZonedDateTime lastUpdate, String lastUpdatedBy, int countryID) throws SQLException {
        String sql = "UPDATE frist_level_divisions SET Division = ?, Create_Date = ?, Created_By = ?, Last_Update = ?, Last_Updated_By = ?, Country_ID WHERE Division_ID ?) VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, divisionID);
        ps.setString(2, divsion);
        ps.setObject(3, createDate);
        ps.setString(4, createBy);
        ps.setObject(5, lastUpdate);
        ps.setString(6, lastUpdatedBy);
        ps.setInt(7,countryID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Delete First Level Division */
    public static int deleteFirstLevelDivisions(int divisionsID) throws SQLException {
        String sql = "DELETE FROM first_level_divisions WHERE Division_ID ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, divisionsID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Selevt First Level Division Query */
    public static void selectFirstLevelDivisions() throws SQLException {
        String sql = "SElECT * FROM first_level_divisions";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int divisionID = rs.getInt("Division_ID");
            String division = rs.getString("Division");
            String createDate = rs.getString("Create_Date");
            String createdBy = rs.getString("Created_By");
            String lastUpdate = rs.getString("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");
            int countryID = rs.getInt("Country_ID");

            System.out.print(divisionID + " | ");
            System.out.print(division + " | ");
            System.out.print(createDate + " | ");
            System.out.print(createdBy + " | ");
            System.out.print(lastUpdate + " | ");
            System.out.print(lastUpdatedBy + " | ");
            System.out.println(countryID);
        }
    }

    // ----------- Users ---------------
    /** Insert Users Query */
    public static int insertUsers(int userID, String userName, String password, LocalTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdatedBy) throws SQLException {
        String sql = "INSERT INTO users (User_ID, User_Name, Password, Create_Date, Created_By, Last_Update, Last_Updated_By) VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, userID);
        ps.setString(2, userName);
        ps.setString(3, password);
        ps.setObject(4, createDate);
        ps.setString(5, createdBy);
        ps.setObject(6, lastUpdate);
        ps.setString(7,lastUpdatedBy);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Update Users Query */
    public static int updateUsers(int userID, String userName, String password, LocalTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdatedBy) throws SQLException {
        String sql = "UPDATE users SET User_Name = ?, Password = ?, Create_Date = ?, Created_By = ?, Last_Update = ?, Last_Updated_By WHERE User_ID ?) VALUES(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, userID);
        ps.setString(2, userName);
        ps.setString(3, password);
        ps.setObject(4, createDate);
        ps.setString(5, createdBy);
        ps.setObject(6, lastUpdate);
        ps.setString(7,lastUpdatedBy);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Delete Users Query */
    public static int deleteUsers(int userID) throws SQLException {
        String sql = "DELETE FROM users WHERE User_ID ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, userID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /** Select Users Query */
    public static void selectUsers() throws SQLException {
        String sql = "SElECT * FROM users";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int userID = rs.getInt("User_ID");
            String userName = rs.getString("User_Name");
            String password = rs.getString("Password");
            Object createDate = rs.getObject("Create_Date");
            String createdBy = rs.getString("Created_By");
            Object lastUpdate = rs.getObject("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");

            System.out.print(userID + " | ");
            System.out.print(userName + " | ");
            System.out.print(password + " | ");
            System.out.print(createDate + " | ");
            System.out.print(createdBy + " | ");
            System.out.print(lastUpdate + " | ");
            System.out.println(lastUpdatedBy);
        }
    }

}
