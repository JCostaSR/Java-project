package com.example.helloworldjfxtemplate.model;

public class appointmentMonthlyFilter {
}
