package com.example.helloworldjfxtemplate.model;

public class appointmentWeeklyFilter {
}
