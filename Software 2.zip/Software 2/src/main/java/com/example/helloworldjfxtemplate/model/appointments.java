package com.example.helloworldjfxtemplate.model;

import com.example.helloworldjfxtemplate.controller.AppointmentsController;
import javafx.scene.control.TableColumn;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZonedDateTime;
/*
Appointment_ID INT(10) (PK)
Title VARCHAR(50)
Description VARCHAR(50)
Location VARCHAR(50)
Type VARCHAR(50)
Start DATETIME
End DATETIME
Create_Date DATETIME
Created_By VARCHAR(50)
Last_Update TIMESTAMP
Last_Updated_By VARCHAR(50
Customer_ID INT(10 (FK)
User_ID INT(10) (FK)
Contact_ID INT(10) (FK)
 */

/**
 * @author John C Costa SR.
 */

public class appointments {
    private int countCol;
    private int appointmentID;
    private String title;
    private String description;
    private String location;
    private String type;
    private LocalDateTime startDateTime;
    private LocalDateTime endDateTime;
    private Object createDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdatedBy;
    private int customerID;
    private String userID;
    private int contactID;

    public appointments(int appointmentID, String title, String description, String location, int contactID, String type, LocalDateTime startDateTime, LocalDateTime endDateTime,
                        int customerID, String userID){
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.contactID = contactID;
        this.type = type;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.customerID = customerID;
        this.userID = userID;
    }

    public appointments(int appointmentID, String title, String type, LocalDateTime startDateTime, LocalDateTime endDateTime, int customerID) {
        this.appointmentID = appointmentID;
        this.title = title;
        this.type = type;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.customerID = customerID;
    }

    public appointments(String type, LocalDateTime startDateTime, int countCol) {
        this.startDateTime = LocalDateTime.from(startDateTime);
        this.type = type;
        this.countCol = countCol;
    }
    public appointments(int appointmentID, String description, String type, int customerID, int contactID){
        this.appointmentID = appointmentID;
        this.description = description;
        this.type = type;
        this.customerID = customerID;
        this.contactID = contactID;
    }
    public appointments(int customerID){
        this.customerID = customerID;
    }

    public appointments() {

    }

    /** @return countCol */
    public int getCountCol() {
        return countCol;
    }
    /** @param countCol  */
    public void setCountCol(int countCol) {
        this.countCol = countCol;
    }

    /** @return appointment ID */
    public int getAppointmentID() {
        return appointmentID;
    }
    /** @param appointmentID  */
    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    /** @return title */
    public String getTitle() {
        return title;
    }
    /** @param title  */
    public void setTitle(String title) {
        this.title = title;
    }

    /** @return description */
    public String getDescription() {
        return description;
    }
    /** @param description  */
    public void setDescription(String description) {
        this.description = description;
    }

    /** @return location */
    public String getLocation() {
        return location;
    }
    /** @param location  */
    public void setLocation(String location) {
        this.location = location;
    }

    /** @return type */
    public String getType() {
        return type;
    }
    /** @param type  */
    public void setType(String type) {
        this.type = type;
    }

    /** @return startDateTime */
    public LocalDateTime getStartDateTime() {
        return startDateTime;
    }
    /** @param startDateTime  */
    public void setStartDateTime(LocalDateTime startDateTime) {
        this.startDateTime = startDateTime;
    }

    /** @return endDateTime */
    public LocalDateTime getEndDateTime() {
        return endDateTime;
    }
    /** @param endDateTime  */
    public void setEndDateTime(LocalDateTime endDateTime) {
        this.endDateTime = endDateTime;
    }

    /** @return createDate */
    public Object getCreateDate() {
        return createDate;
    }
    /** @param createDate  */
    public void setCreateDate(Object createDate) {
        this.createDate = createDate;
    }

    /** @return createdBy */
    public String getCreatedBy() {
        return createdBy;
    }
    /** @param createdBy  */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /** @return lastUpdate */
    public Timestamp getLastUpdate() {
        return lastUpdate;
    }
    /** @param lastUpdate  */
    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /** @return lastUpdatedBy */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /** @param lastUpdatedBy */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /** @return customerID */
    public int getCustomerID() {
        return customerID;
    }
    /** @param customerID  */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /** @return userID */
    public String getUserID() {
        return userID;
    }
    /** @param userID  */
    public void setUserID(String userID) {
        this.userID = userID;
    }

    /** @return contactID */
    public int getContactID() {
        return contactID;
    }
    /** @param contactID  */
    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    /** All appointments */
    public static int getAllAppointments() {
        for(int i = 0; i < 5; i++) {
        }
        return getAllAppointments();
    }

}
