package com.example.helloworldjfxtemplate.model;

/*
Contact_ID INT(10) (PK)
Contact_Name VARCHAR(50)
Email VARCHAR(50)
 */

/**
 * @author John C Costa
 */

public class contacts {
    private static int contactID;
    private String contactName;
    private String email;

    public contacts(int contactID, String contactName, String email){
        this.contactID = contactID;
        this.contactName = contactName;
        this.email = email;

    }

    /** @return contactID */
    public static int getContactID() {
        return contactID;
    }
    /** @param contactID  */
    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    /** @return contactName */
    public String getContactName() {
        return contactName;
    }
    /** @param contactName  */
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    /** @return email */
    public String getEmail() {
        return email;
    }
    /** @param email  */
    public void setEmail(String email) {
        this.email = email;
    }
}
