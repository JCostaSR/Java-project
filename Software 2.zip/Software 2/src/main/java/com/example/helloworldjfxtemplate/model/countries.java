package com.example.helloworldjfxtemplate.model;
import java.time.LocalTime;
import java.time.ZonedDateTime;

/*
Country_ID INT(10) (PK)
Country VARCHAR(50)
Create_Date DATETIME
Created_By VARCHAR(50)
Last_Update TIMESTAMP
Last_Updated_By VARCHAR(50)
 */

/**
 * @author John C Costa SR.
 */

public class countries {
    private int countryID;
    private String country;
    private LocalTime createdDate;
    private String createdBy;
    private ZonedDateTime lastUpdate;
    private String lastUpdatedBy;

    public countries(int countryID, String country, LocalTime createDate, String createdBy, ZonedDateTime lastUpdate, String lastUpdatedBy){
        this.countryID = countryID;
        this.country = country;
        this.createdDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /** @return countryID */
    public int getCountryID() {
        return countryID;
    }
    /** @param countryID  */
    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    /** @return country */
    public String getCountry() {
        return country;
    }
    /** @param country  */
    public void setCountry(String country) {
        this.country = country;
    }

    /** @return createdDate */
    public LocalTime getCreatedDate() {
        return createdDate;
    }
    /** @param createdDate  */
    public void setCreatedDate(LocalTime createdDate) {
        this.createdDate = createdDate;
    }

    /** @return createdBy */
    public String getCreatedBy() {
        return createdBy;
    }
    /** @param createdBy  */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /** @return lastUpdate */
    public ZonedDateTime getLastUpdate() {
        return lastUpdate;
    }
    /** @param lastUpdate  */
    public void setLastUpdate(ZonedDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /** @return lastUpdateBy */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /** @param lastUpdatedBy  */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
}
