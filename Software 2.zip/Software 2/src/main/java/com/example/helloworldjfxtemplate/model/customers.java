package com.example.helloworldjfxtemplate.model;
/*
Customer_ID int AI PK
Customer_Name Varchar(50)
Address varchar(100)
Postal_Code varchar(50)
Phone varcher(50)
Create datetime
Created_By varchar(50)
Last_Update datetime
Last_Updated_By varchar(50)
Division_ID int
 */

import java.time.LocalDateTime;

/**
 * @author John C Costa SR.
 */

public class customers {
    private int customerID;
    private String customerName;
    private String address;
    private String postalCode;
    private String phoneNumber;
    private LocalDateTime createDate;
    private String createdBy;
    private LocalDateTime lastUpdate;
    private String lastUpdatedBy;
    private int divisionID;

    public customers(int customerID, String customerName, String address, String postalCode, String phoneNumber) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phoneNumber = phoneNumber;
    }
    public customers(int customerID, String customerName, String address, String postalCode, String phoneNumber, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String lastUpdatedBy,  int divisionID) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phoneNumber = phoneNumber;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.divisionID = divisionID;
    }
    /**@return createDate*/
    public LocalDateTime getCreateDate() {
        return createDate;
    }
    /** @param createDate*/
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }
    /** @return createdBy */
    public String getCreatedBy() {
        return createdBy;
    }
    /**  @param createdBy */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    /**  @return lastUpdate */
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    /**  @param lastUpdate */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    /**  @return lastUpdaedBy */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /**  @param lastUpdatedBy */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    /** @return divisionID */
    public int getDivisionID() {
        return divisionID;
    }
    /** @param divisionID */
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    /** @return customerID */
    public int getCustomerID() {
        return customerID;
    }
    /** @param customerID  */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /** @return customerName */
    public String getCustomerName() {
        return customerName;
    }
    /** @param customerName  */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /** @return address */
    public String getAddress() {
        return address;
    }
    /** @param address  */
    public void setAddress(String address) {
        this.address = address;
    }

    /** @return postalCode */
    public String getPostalCode() {
        return postalCode;
    }
    /** @param postalCode  */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /** @return phoneNumber */
    public String getPhoneNumber() {
        return phoneNumber;
    }
    /** @param phoneNumber  */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
