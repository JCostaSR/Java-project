package com.example.helloworldjfxtemplate.model;
import java.time.LocalTime;
import java.time.ZonedDateTime;
/*
Division_ID INT(10) (PK)
Division VARCHAR(50)
Create_Date DATETIME
Created_By VARCHAR(50)
Last_Update TIMESTAMP
Last_Updated_By VARCHAR(50)
Country_ID INT(10) (FK)
 */

/**
 * @author John C Costa SR.
 */

public class first_level_divisions {
    private int divisionID;
    private String division;
    private LocalTime createDate;
    private String createdBy;
    private ZonedDateTime lastUpdate;
    private String lastUpdatedBy;
    private int countryID;

    public first_level_divisions() {

    }

    /** @return divisionID */
    public int getDivisionID() {
        return divisionID;
    }
    /** @param divisionID  */
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    /** @return division */
    public String getDivision() {
        return division;
    }
    /** @param division  */
    public void setDivision(String division) {
        this.division = division;
    }

    /** @return createDate */
    public LocalTime getCreateDate() {
        return createDate;
    }
    /** @param createDate  */
    public void setCreateDate(LocalTime createDate) {
        this.createDate = createDate;
    }

    /** @return createdBy */
    public String getCreatedBy() {
        return createdBy;
    }
    /** @param createdBy  */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /** @return lastUpdate */
    public ZonedDateTime getLastUpdate() {
        return lastUpdate;
    }
    /** @param lastUpdate  */
    public void setLastUpdate(ZonedDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /** @return lastUpdatedBy */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /** @param lastUpdatedBy  */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    /** @return countryID */
    public int getCountryID() {
        return countryID;
    }
    /** @param countryID  */
    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }
}
