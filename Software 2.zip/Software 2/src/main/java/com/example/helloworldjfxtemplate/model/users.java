package com.example.helloworldjfxtemplate.model;
import java.sql.Time;

/*
User_ID INT(10) (PK)
User_Name VARCHAR(50) (UNIQUE)
Password TEXT
Create_Date DATETIME
Created_By VARCHAR(50)
Last_Update TIMESTAMP
Last_Updated_By VARCHAR(50)
 */

/**
 * @author John C Costa SR.
 */

public class users {
    private int userID;
    private String userName;
    private String password;
    private Time createDate;
    private String createdBy;
    private Time lastUpdate;
    private String lastUpdatedBy;


    public users(int userID, String userName, Time createDate, String createdBy, Time lastUpdate, String lastUpdatedBy) {
        this.userID = userID;
        this.userName = userName;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public users(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    /** @return userID */
    public int getUserID() {
        return userID;
    }
    /** @param userID  */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /** @return userName */
    public String getUserName() {
        return userName;
    }
    /** @param userName  */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /** @return password */
    public String getPassword() {
        return password;
    }
    /** @param password  */
    public void setPassword(String password) {
        this.password = password;
    }

    /** @return createDate */
    public Time getCreateDate() {
        return createDate;
    }
    /** @param createDate  */
    public void setCreateDate(Time createDate) {
        this.createDate = createDate;
    }

    /** @return createdBy */
    public String getCreatedBy() {
        return createdBy;
    }
    /** @param createdBy  */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /** @return lastUpdate */
    public Time getLastUpdate() {
        return lastUpdate;
    }
    /** @param lastUpdate  */
    public void setLastUpdate(Time lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    /** @return lastUpdatedBy */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /** @param lastUpdatedBy  */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
}
